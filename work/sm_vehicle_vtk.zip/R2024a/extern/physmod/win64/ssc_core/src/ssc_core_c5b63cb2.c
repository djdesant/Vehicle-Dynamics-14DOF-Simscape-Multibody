#include "pm_std.h"
#include "ssc_dae_fwd.h"
struct NeCustomDataSizeTag{size_t ssc_core_VOAPNvYIRPGzhDXn1iCcKS;size_t
ssc_core_kAKxIvM1NQGM_TY96YysC5;};struct NeCustomDataTag{double*
ssc_core_VOMV27LEztpmd59gF8yJO0;int32_T*ssc_core_F85sNEuWe1GIjmiT6vHSvn;
NeCustomDataSize mSizes;NeCustomData*ssc_core__HGpmB64in_eWHsZP7Cb0h;};
NeCustomDataSize ssc_core_kvaTUFehmelwWDNafwUyA0(void);NeCustomData*
ssc_core_VFzWBz_s8FW9_qamuHujnl(NeCustomDataSize sizes);NeCustomData*
ssc_core__uWFHemgRS83bDIJli34aR(void);void ne_free_custom_data(NeCustomData*
ssc_core_FQj37QqwZMSgjLC3bhgfpn);size_t ne_measure_packed_custom_data(const
NeCustomData*ssc_core_FQj37QqwZMSgjLC3bhgfpn);void ne_pack_custom_data(const
NeCustomData*ssc_core_FQj37QqwZMSgjLC3bhgfpn,char*
ssc_core_V0vDZJ8GoT_FY58vl_R6tv);NeCustomData*ne_recreate_custom_data(const
char*ssc_core_V0vDZJ8GoT_FY58vl_R6tv,size_t ssc_core__Mwijnrb0M46cT7T_bvxpH);
#include "string.h"
#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
#include "ne_std.h"
NeCustomDataSize ssc_core_kvaTUFehmelwWDNafwUyA0(void){NeCustomDataSize
mc__0REJ38_cKO_bunM1JCRT_;mc__0REJ38_cKO_bunM1JCRT_.
ssc_core_VOAPNvYIRPGzhDXn1iCcKS=0;mc__0REJ38_cKO_bunM1JCRT_.
ssc_core_kAKxIvM1NQGM_TY96YysC5=0;return mc__0REJ38_cKO_bunM1JCRT_;}
NeCustomData*ssc_core_VFzWBz_s8FW9_qamuHujnl(NeCustomDataSize sizes){
NeCustomData*ssc_core_FQj37QqwZMSgjLC3bhgfpn=(NeCustomData*)pmf_malloc(sizeof(
NeCustomData));ssc_core_FQj37QqwZMSgjLC3bhgfpn->mSizes=sizes;
ssc_core_FQj37QqwZMSgjLC3bhgfpn->ssc_core_VOMV27LEztpmd59gF8yJO0=(double*)
pmf_calloc(sizes.ssc_core_VOAPNvYIRPGzhDXn1iCcKS,sizeof(double));
ssc_core_FQj37QqwZMSgjLC3bhgfpn->ssc_core_F85sNEuWe1GIjmiT6vHSvn=(int32_T*)
pmf_calloc(sizes.ssc_core_kAKxIvM1NQGM_TY96YysC5,sizeof(int32_T));
ssc_core_FQj37QqwZMSgjLC3bhgfpn->ssc_core__HGpmB64in_eWHsZP7Cb0h=NULL;return
ssc_core_FQj37QqwZMSgjLC3bhgfpn;}NeCustomData*ssc_core__uWFHemgRS83bDIJli34aR(
void){return ssc_core_VFzWBz_s8FW9_qamuHujnl(ssc_core_kvaTUFehmelwWDNafwUyA0()
);}void ne_free_custom_data(NeCustomData*ssc_core_FQj37QqwZMSgjLC3bhgfpn){if(
ssc_core_FQj37QqwZMSgjLC3bhgfpn->ssc_core__HGpmB64in_eWHsZP7Cb0h!=NULL){
ne_free_custom_data(ssc_core_FQj37QqwZMSgjLC3bhgfpn->
ssc_core__HGpmB64in_eWHsZP7Cb0h);}pmf_free(ssc_core_FQj37QqwZMSgjLC3bhgfpn->
ssc_core_VOMV27LEztpmd59gF8yJO0);pmf_free(ssc_core_FQj37QqwZMSgjLC3bhgfpn->
ssc_core_F85sNEuWe1GIjmiT6vHSvn);pmf_free(ssc_core_FQj37QqwZMSgjLC3bhgfpn);}
size_t ne_measure_packed_custom_data(const NeCustomData*
ssc_core_FQj37QqwZMSgjLC3bhgfpn){if(ssc_core_FQj37QqwZMSgjLC3bhgfpn==NULL){
return 0;}else{return(sizeof(size_t)+sizeof(size_t)+
ssc_core_FQj37QqwZMSgjLC3bhgfpn->mSizes.ssc_core_VOAPNvYIRPGzhDXn1iCcKS*sizeof
(double)+ssc_core_FQj37QqwZMSgjLC3bhgfpn->mSizes.
ssc_core_kAKxIvM1NQGM_TY96YysC5*sizeof(int32_T)+ne_measure_packed_custom_data(
ssc_core_FQj37QqwZMSgjLC3bhgfpn->ssc_core__HGpmB64in_eWHsZP7Cb0h));}}static
void ssc_core_Vfjg8emSPqlNXicm2Wfoeg(char*mc__AExROh1PVWNeP7hmMWuJv,size_t*
ssc_core__Mwijnrb0M46cT7T_bvxpH,size_t pm_kpzAtHMD4_WnheH0UiioSE){const size_t
size=sizeof(pm_kpzAtHMD4_WnheH0UiioSE);memcpy(mc__AExROh1PVWNeP7hmMWuJv+*
ssc_core__Mwijnrb0M46cT7T_bvxpH,&pm_kpzAtHMD4_WnheH0UiioSE,size);*
ssc_core__Mwijnrb0M46cT7T_bvxpH+=size;}static void
ssc_core_FtkXmSTXTvhCWHYWhVDLJ9(char*mc__AExROh1PVWNeP7hmMWuJv,size_t*
ssc_core__Mwijnrb0M46cT7T_bvxpH,int32_T pm_kpzAtHMD4_WnheH0UiioSE){const size_t
size=sizeof(pm_kpzAtHMD4_WnheH0UiioSE);memcpy(mc__AExROh1PVWNeP7hmMWuJv+*
ssc_core__Mwijnrb0M46cT7T_bvxpH,&pm_kpzAtHMD4_WnheH0UiioSE,size);*
ssc_core__Mwijnrb0M46cT7T_bvxpH+=size;}static void
ssc_core_kml4HooECdptdyqTSz3Upy(char*mc__AExROh1PVWNeP7hmMWuJv,size_t*
ssc_core__Mwijnrb0M46cT7T_bvxpH,double pm_kpzAtHMD4_WnheH0UiioSE){const size_t
size=sizeof(pm_kpzAtHMD4_WnheH0UiioSE);memcpy(mc__AExROh1PVWNeP7hmMWuJv+*
ssc_core__Mwijnrb0M46cT7T_bvxpH,&pm_kpzAtHMD4_WnheH0UiioSE,size);*
ssc_core__Mwijnrb0M46cT7T_bvxpH+=size;}static size_t
ssc_core_Fyb6FR32q1SldiG2cyyQki(const char**mc__AExROh1PVWNeP7hmMWuJv,size_t*
ssc_core__Mwijnrb0M46cT7T_bvxpH){size_t pm_kpzAtHMD4_WnheH0UiioSE;const size_t
size=sizeof(pm_kpzAtHMD4_WnheH0UiioSE);memcpy(&pm_kpzAtHMD4_WnheH0UiioSE,*
mc__AExROh1PVWNeP7hmMWuJv,size);*mc__AExROh1PVWNeP7hmMWuJv+=size;*
ssc_core__Mwijnrb0M46cT7T_bvxpH-=size;return pm_kpzAtHMD4_WnheH0UiioSE;}static
int32_T ssc_core_VmV_jQ65L4OugejQpKugvW(const char**mc__AExROh1PVWNeP7hmMWuJv,
size_t*ssc_core__Mwijnrb0M46cT7T_bvxpH){int32_T pm_kpzAtHMD4_WnheH0UiioSE;
const size_t size=sizeof(pm_kpzAtHMD4_WnheH0UiioSE);memcpy(&
pm_kpzAtHMD4_WnheH0UiioSE,*mc__AExROh1PVWNeP7hmMWuJv,size);*
mc__AExROh1PVWNeP7hmMWuJv+=size;*ssc_core__Mwijnrb0M46cT7T_bvxpH-=size;return
pm_kpzAtHMD4_WnheH0UiioSE;}static double ssc_core_kgDdSMIsdwClaDyhTsoQfU(const
char**mc__AExROh1PVWNeP7hmMWuJv,size_t*ssc_core__Mwijnrb0M46cT7T_bvxpH){double
pm_kpzAtHMD4_WnheH0UiioSE;const size_t size=sizeof(pm_kpzAtHMD4_WnheH0UiioSE);
memcpy(&pm_kpzAtHMD4_WnheH0UiioSE,*mc__AExROh1PVWNeP7hmMWuJv,size);*
mc__AExROh1PVWNeP7hmMWuJv+=size;*ssc_core__Mwijnrb0M46cT7T_bvxpH-=size;return
pm_kpzAtHMD4_WnheH0UiioSE;}void ne_pack_custom_data(const NeCustomData*
ssc_core_FQj37QqwZMSgjLC3bhgfpn,char*ssc_core_V0vDZJ8GoT_FY58vl_R6tv){if(
ssc_core_FQj37QqwZMSgjLC3bhgfpn!=NULL){size_t ssc_core__Mwijnrb0M46cT7T_bvxpH=
0;size_t mc_kwrB3ZoKf7OufTHWaHJV7a;ssc_core_Vfjg8emSPqlNXicm2Wfoeg(
ssc_core_V0vDZJ8GoT_FY58vl_R6tv,&ssc_core__Mwijnrb0M46cT7T_bvxpH,
ssc_core_FQj37QqwZMSgjLC3bhgfpn->mSizes.ssc_core_VOAPNvYIRPGzhDXn1iCcKS);
ssc_core_Vfjg8emSPqlNXicm2Wfoeg(ssc_core_V0vDZJ8GoT_FY58vl_R6tv,&
ssc_core__Mwijnrb0M46cT7T_bvxpH,ssc_core_FQj37QqwZMSgjLC3bhgfpn->mSizes.
ssc_core_kAKxIvM1NQGM_TY96YysC5);for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<ssc_core_FQj37QqwZMSgjLC3bhgfpn->mSizes.
ssc_core_VOAPNvYIRPGzhDXn1iCcKS;mc_kwrB3ZoKf7OufTHWaHJV7a++){
ssc_core_kml4HooECdptdyqTSz3Upy(ssc_core_V0vDZJ8GoT_FY58vl_R6tv,&
ssc_core__Mwijnrb0M46cT7T_bvxpH,ssc_core_FQj37QqwZMSgjLC3bhgfpn->
ssc_core_VOMV27LEztpmd59gF8yJO0[mc_kwrB3ZoKf7OufTHWaHJV7a]);}for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
ssc_core_FQj37QqwZMSgjLC3bhgfpn->mSizes.ssc_core_kAKxIvM1NQGM_TY96YysC5;
mc_kwrB3ZoKf7OufTHWaHJV7a++){ssc_core_FtkXmSTXTvhCWHYWhVDLJ9(
ssc_core_V0vDZJ8GoT_FY58vl_R6tv,&ssc_core__Mwijnrb0M46cT7T_bvxpH,
ssc_core_FQj37QqwZMSgjLC3bhgfpn->ssc_core_F85sNEuWe1GIjmiT6vHSvn[
mc_kwrB3ZoKf7OufTHWaHJV7a]);}ne_pack_custom_data(
ssc_core_FQj37QqwZMSgjLC3bhgfpn->ssc_core__HGpmB64in_eWHsZP7Cb0h,
ssc_core_V0vDZJ8GoT_FY58vl_R6tv+ssc_core__Mwijnrb0M46cT7T_bvxpH);}}
NeCustomData*ne_recreate_custom_data(const char*
ssc_core_V0vDZJ8GoT_FY58vl_R6tv,size_t ssc_core__Mwijnrb0M46cT7T_bvxpH){
NeCustomData*ssc_core_FQj37QqwZMSgjLC3bhgfpn=NULL;if(
ssc_core__Mwijnrb0M46cT7T_bvxpH>0){NeCustomDataSize mc__0REJ38_cKO_bunM1JCRT_;
size_t mc_kwrB3ZoKf7OufTHWaHJV7a;mc__0REJ38_cKO_bunM1JCRT_.
ssc_core_VOAPNvYIRPGzhDXn1iCcKS=ssc_core_Fyb6FR32q1SldiG2cyyQki(&
ssc_core_V0vDZJ8GoT_FY58vl_R6tv,&ssc_core__Mwijnrb0M46cT7T_bvxpH);
mc__0REJ38_cKO_bunM1JCRT_.ssc_core_kAKxIvM1NQGM_TY96YysC5=
ssc_core_Fyb6FR32q1SldiG2cyyQki(&ssc_core_V0vDZJ8GoT_FY58vl_R6tv,&
ssc_core__Mwijnrb0M46cT7T_bvxpH);ssc_core_FQj37QqwZMSgjLC3bhgfpn=
ssc_core_VFzWBz_s8FW9_qamuHujnl(mc__0REJ38_cKO_bunM1JCRT_);for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
ssc_core_FQj37QqwZMSgjLC3bhgfpn->mSizes.ssc_core_VOAPNvYIRPGzhDXn1iCcKS;
mc_kwrB3ZoKf7OufTHWaHJV7a++){ssc_core_FQj37QqwZMSgjLC3bhgfpn->
ssc_core_VOMV27LEztpmd59gF8yJO0[mc_kwrB3ZoKf7OufTHWaHJV7a]=
ssc_core_kgDdSMIsdwClaDyhTsoQfU(&ssc_core_V0vDZJ8GoT_FY58vl_R6tv,&
ssc_core__Mwijnrb0M46cT7T_bvxpH);}for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<ssc_core_FQj37QqwZMSgjLC3bhgfpn->mSizes.
ssc_core_kAKxIvM1NQGM_TY96YysC5;mc_kwrB3ZoKf7OufTHWaHJV7a++){
ssc_core_FQj37QqwZMSgjLC3bhgfpn->ssc_core_F85sNEuWe1GIjmiT6vHSvn[
mc_kwrB3ZoKf7OufTHWaHJV7a]=ssc_core_VmV_jQ65L4OugejQpKugvW(&
ssc_core_V0vDZJ8GoT_FY58vl_R6tv,&ssc_core__Mwijnrb0M46cT7T_bvxpH);}
ssc_core_FQj37QqwZMSgjLC3bhgfpn->ssc_core__HGpmB64in_eWHsZP7Cb0h=
ne_recreate_custom_data(ssc_core_V0vDZJ8GoT_FY58vl_R6tv,
ssc_core__Mwijnrb0M46cT7T_bvxpH);}return ssc_core_FQj37QqwZMSgjLC3bhgfpn;}
