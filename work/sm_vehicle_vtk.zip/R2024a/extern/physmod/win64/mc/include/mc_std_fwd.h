#ifndef __mc_std_fwd_h__
#define __mc_std_fwd_h__
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
typedef struct McRealFunctionTag McRealFunction;typedef struct McIntFunctionTag
McIntFunction;typedef struct McMatrixFunctionTag McMatrixFunction;typedef
struct McLinearAlgebraFactoryTag McLinearAlgebraFactory;typedef struct
McLinearAlgebraTag McLinearAlgebra;
#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __mc_std_fwd_h__ */
