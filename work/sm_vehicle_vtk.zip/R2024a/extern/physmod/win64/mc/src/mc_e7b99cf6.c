#include "pm_std.h"
#include "pm_std.h"
#include "mc_std_fwd.h"
#include "mc_std_fwd.h"
#include "pm_std.h"
boolean_T mc_kOXeAPjCQDOxhXky_1MsMG(PmRealVector*mc__cCFC__DnidYg1kaNwxKZX,
PmRealVector*mc_VCpFjH0ABOdob1GmQhWaMX,PmRealVector*mc_Vg4sTMCV5NdPVemjId5WuL,
PmRealVector*mc__iaU8xWcwKOLgTx0Fs51s0,const PmSparsityPattern*
mc__67mUhUuDV4sharm2fatDC,const PmRealVector*mc_FfDTppU8N_tOWuLK37x_08,const
size_t mc_V0jiAH2gCJ_zYedoHqBU86);boolean_T mc__TiJ6aR0GmK9WTqtHi6sGL(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const real_T mc_kUQBO1dSP8_IVqRAUx4R8G,const size_t
mc_V0jiAH2gCJ_zYedoHqBU86);real_T mc_kAKaeZRaJJO_jm2uJ1aLnZ(const PmRealVector
*pm__hARyx1bZBxVj1boVQqdtV,size_t mc_V0jiAH2gCJ_zYedoHqBU86);
#include "math.h"
#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
size_t mc_VgM3Lx3pYgtLW13T1_txvP(const PmBoolVector*mc_VgJW5ZqpwPpuY1inYtaofQ)
;void mc_F4xMxEJX_DlUYXuaiDuSWS(const PmIntVector*mc_kyVj_uOQd__gg9_ljlZ_IY,
const PmRealVector*x,const PmRealVector*mc_FfDTppU8N_tOWuLK37x_08);void
mc_kQso3OAQDyxZaX0RF40IyE(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmIntVector*
mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_FCOSZaHMkXC6hyEys7zO54(const PmIntVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmIntVector*mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_V5jydIk5QzCRZTOycShqTL(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FvLmE29WKCKJfaZMHwg3g9(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const int32_T mc_kh0AzKGHcX8tfeDoNul_TU,
const int32_T mc__Oliq0seKPWShTNRpvAarb);void mc__pmVtsSuXZls_1NfvVprZ7(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH);void
mc_FR5FdJeEvDGGcyEVkxeE_x(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,boolean_T mc_FL_3a__K44dYi9fe74WHqt);
void mc_FK6EqkTbVFGMZ5QwXcurHx(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*mc_k8AO2tT20x0_cyxVp0ak3P);void mc_FioOBDJiFMpkWaAcUdBb1E(
const PmIntVector*mc_F6RwpxHXSXp7gDlfFRloPz,int32_T mc_kg4CyRgbu6OdeewZOel7Qx)
;void mc_kB1aHs1BVHG5YHNpmLLvkW(const PmBoolVector*mc_FrF2gTbWxox8geiSROFaFn,
const PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__vpsWwfj3fx1YDJlP_lHTd);void mc_V2P87Xoe0TGNeXNcn27vUJ(const PmBoolVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmBoolVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_VqP4HesDIf47bDn5teE2H2(const PmRealVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmRealVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_Vv4EJYeJDW0yZXiH42yCA_(const PmIntVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmIntVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_k0zonBZJC2K6baT1NXX1Qo(PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);size_t
mc_FLTxr_Wc1PKSeTxwfrcl5B(const PmBoolVector*mc__MqKyOds56_XeH9Iv3CTIL);void
mc_FX5UXdAa2flS_1wrwznTLh(const PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,const
PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE);size_t mc__RsEbvPhcXp6iqwYpH_OQY(const
PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);size_t mc__fQVSVSgEBG6fuximVFlkw(const
PmRealVector*mc_FawmFe5oOEC_cmkvZc1Kaa);size_t mc_FyLahU0kjICfba8O7mWi8Z(const
PmBoolVector*mc_FawmFe5oOEC_cmkvZc1Kaa);boolean_T mc___gjB_jZtTxReaWZSEiFdh(
const PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);boolean_T
mc_kNrn2e3NmaGNbmzmXpvCR0(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,int32_T
mc_kg4CyRgbu6OdeewZOel7Qx);boolean_T mc_kk65_VI6zC0mWHqRziXpjX(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_FGkd8Riw6p4eaDCAbwBVPv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FzkrLuS4xMOvaTv5dUw3j7(const
PmRealVector*x,real_T mc_VgJW5ZqpwPpuY1inYtaofQ);void mc_ks_PW4I7dwWbhXAWhHTUCI
(const PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc__w_RD4J1MZlqcL7as8FLdk(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V3CZVT50_V_xeia9SYYptc(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T a,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_VIFqLU9Z6UtwXDWPnvd_zg(const PmRealVector*x
,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_FBDi_PCg670TjHgJTNPcHr);void mc_VWnvos7Q548uVH7p0208jN(const PmRealVector*x
,const real_T a,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_V7hiVZfxKK0Uj9rPai4LYw(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
real_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VM9M6KxYTfKL_q4yuXmOnI(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const real_T mc_kcda_aHAM4WIXuM_xBDdLt)
;void mc_k4v_yYmXHgO1cqVdr5a500(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V2CDnBdRcOpuh1IyvRJzfi(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FNVEyWT4js4ebmsePvfFh2(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc__dsFCQJjA6p_j1tGhi2wWe(const PmRealVector*mc_VcZASgthsTt6dul8DlRWaw,real_T
mc_kcda_aHAM4WIXuM_xBDdLt);void mc_kUD9LJQRjT0FayfqpQrhnP(const PmBoolVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc__NFj_YrtCgd3dDixI_yrA7(const PmRealVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc__aNO1s5qwzt6fXwft5YgCz(const PmRealVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc_FzUHnQbqf_dRhX_X5DoWjW(const PmRealVector*
mc_VcZASgthsTt6dul8DlRWaw,size_t mc_kwrB3ZoKf7OufTHWaHJV7a,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_VTlukZ0iimdzge7aTGg7rl(const PmIntVector*
mc_VcZASgthsTt6dul8DlRWaw,int32_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_VDWYuA0FfQClgukbQcp3js(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc_k9wkPuvMCi4DY1yebDQPHf(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc__Nb_EyyxYi4ddPcS0H7Bot(const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH,const
PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);
void mc_k1sxUtEClkOZVuHMQ91JqD(const PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw,
boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VWloU5QD6gpaXeK8lmytFA(const
PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw);void mc_VQ1YWbKmkVC6YajZAyvmNH(const
PmBoolVector*x,size_t mc_kwrB3ZoKf7OufTHWaHJV7a,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc__uq8ZXcr_B_zgDxjibJDSi(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc_FnkaeEp6tpWlhHVVTP_g3C(const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);real_T mc_F1fvRD4xlFhBdyqJtcgdmn(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);real_T mc_kMPF5fccZd_3jHFMhUSro6(const
PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_kvxcenZbLm4dfenXL8jQAx(
const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_Vgo5SAIS_80_VXwmU7JogX
(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);void mc__25pQTf4VutiXiGTGQmvSU(
PmIntVector*mc__nP_wNlJUxWHWLytmZ4pL0,const PmIntVector*
mc_F6sy5cXK8JOKeiFBw6znSV);void mc__LECH_YE38C6YH4eYxxbSd(PmRealVector*
mc_VWoEnwEgWFpobmwHA1Qln5,const PmRealVector*mc_V_rxJBbuhqtwViRHFKhdGC,const
PmSparsityPattern*mc__Df1hQFzAY4fiLCvP0PV12);void mc_VMRKMuNLnDxXjaBiy1RcMD(
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc__04jybcJBjxwWX7Razqutu(const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const
PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*
mc_VDugqW09uVW_VLuociwzvN);void mc_VjtwQ41FT3hkaixcsQFmQH(const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*mc_VDugqW09uVW_VLuociwzvN);void mc_kM_Y9u9U2F_Cf9sWAtmMMu(
const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void mc__Xq_g76c6Y_K_PpYNKcquN(
const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const real_T*x);void mc_kXj99iXjC1CoZLWwPRH879(const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const
PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*
mc_FybTf2SinthyWqOxvPdJ5h,size_t mc_VVRAoFgW2Hphcy7H6H9Oh0);void
mc__75oXIAh8pt6cyvuqOckyG(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*mc_VxvrZHk3QVKlWycYYdZEat);void mc_kLGj2IdnGDG_YeEKAnMkUr(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FJN_drUOKh_igHJXVH7xls(
const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_V8ujEMKrDU8Q_mvu4yja1b,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
size_t mc_kyp6uAyJE40UVuAQNEYzS1,real_T mc_kcda_aHAM4WIXuM_xBDdLt);void
mc__WqQP6u7DtdYVDzUK5y971(const PmRealVector*mc_FBDi_PCg670TjHgJTNPcHr,const
PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_kc89O49Oe18lWqn1Nr_t61(const PmRealVector*mc_FrF2gTbWxox8geiSROFaFn,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__sdtG1OgJQtqcikFA20Doo);void mc_F4wnJSMmz0WHaHs2tnfI5y(const PmRealVector*
mc_FrF2gTbWxox8geiSROFaFn,const PmIntVector*mc__sdtG1OgJQtqcikFA20Doo,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE);void mc_VjzTgsx19j0KfHv6VXr4Mp(const
PmRealVector*a,const PmIntVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*
b);void mc_V_Fp06wJOBhXZyLbA5xU0r(const PmRealVector*a,const PmRealVector*b,
const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a);void mc_FuY0t5xEb5_QhDQFQ_TXtc(
const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_kkPot0UJiN_EX94QlR_mCs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,real_T x);void mc_kMo1w3ReRZGIdH5_MNwumc
(const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_VYxtXnMKT6hpb1FMldBDLs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void
mc_kl_UmQrKbdCajPyXz5nOIL(const PmRealVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void mc_k2E2oWXDqshMeuCQWrbaKT
(const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc_FBaB5196Xx0ohX_IWM5ypL(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T x);void
mc_F1CG0fHJYfd_ealLMx7Z7U(const PmIntVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void mc_krXbD205SBpghif1h1n_ei(
const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc__Qtfmi680EKpj1bOrIroGr(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void
mc__0IkRn0eQ9Wc_u8mCNbQDh(const PmIntVector*mc_VUELvXWGXPlKf1brR9MRC3,const
PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void mc__pbFNjwg_bCPdPFSjC2Wdv(
const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*
mc_FBOWjCOBM8SyhqFe64oqrx);void mc_VpjBXBa8TTCl_uBXYMLfxC(const PmBoolVector*
mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);
void mc__pFtu1g17h8ZaaZK4PpTkb(const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,
const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void
mc_kMScbNM1RKOTaD4QwTME8Y(const PmBoolVector*mc__1Zf2IciMRCub1vvbEr1C4,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmRealVector*
mc_VlnhKi82gfCLgumIqeduOq);void mc_Fbsqat6MlL0bjPHlNxax8t(const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FSAdXYnRP9pkfmWBYlMkJJ(
const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const PmSparsityPattern*
mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*mc_F8fT7naL9bOcimTADCVzTC);void
mc__NertSre4cWh_mN2RJ5UPq(const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*
mc_VCVhWy_VaDhraHrlfFWxBa);PmRealVector mc_VPFwoVShg1G3XTwou1_jbC(const
PmRealVector*mc_VgJW5ZqpwPpuY1inYtaofQ,size_t mc_Fyss_XM3F_C4dm6IKoDw4G,size_t
mc_Vs6xonQX17Krc5vXv8T_zq);boolean_T mc_kOXeAPjCQDOxhXky_1MsMG(PmRealVector*
mc__cCFC__DnidYg1kaNwxKZX,PmRealVector*mc_VCpFjH0ABOdob1GmQhWaMX,PmRealVector*
mc_Vg4sTMCV5NdPVemjId5WuL,PmRealVector*mc__iaU8xWcwKOLgTx0Fs51s0,const
PmSparsityPattern*mc__67mUhUuDV4sharm2fatDC,const PmRealVector*
mc_FfDTppU8N_tOWuLK37x_08,const size_t mc_V0jiAH2gCJ_zYedoHqBU86){size_t
mc_FLkVm9soKgKChDbdna7u3o=mc_VCpFjH0ABOdob1GmQhWaMX->mN;size_t
mc_V5LBNJCbhICNbmMG_hLaZ6=mc_Vg4sTMCV5NdPVemjId5WuL->mN;int32_T*
mc_kXeDcvuOSpSqamcA4a5jc_=mc__67mUhUuDV4sharm2fatDC->mJc;int32_T*
mc_VEXzFHKjFN87iiOtLrddNz=mc__67mUhUuDV4sharm2fatDC->mIr;real_T*
mc_VlnhKi82gfCLgumIqeduOq=mc__iaU8xWcwKOLgTx0Fs51s0->mX;real_T*
mc_Voyd06CWr20ad1V_wcUTVW=mc__cCFC__DnidYg1kaNwxKZX->mX;real_T*x=
mc_Vg4sTMCV5NdPVemjId5WuL->mX;real_T*mc_Fe6copTTRcKEayCm87ABO_=
mc_VCpFjH0ABOdob1GmQhWaMX->mX;real_T mc_kEw8RhbAZIGdfeViKpSqbH=pmf_get_eps();
size_t mc_kyp6uAyJE40UVuAQNEYzS1=0;int32_T mc_kwrB3ZoKf7OufTHWaHJV7a=0;(void)0
;;(void)0;;(void)0;;(void)0;;(void)0;;mc__aNO1s5qwzt6fXwft5YgCz(
mc__cCFC__DnidYg1kaNwxKZX);for(mc_kyp6uAyJE40UVuAQNEYzS1=0;
mc_kyp6uAyJE40UVuAQNEYzS1<mc_V5LBNJCbhICNbmMG_hLaZ6;mc_kyp6uAyJE40UVuAQNEYzS1
++){for(mc_kwrB3ZoKf7OufTHWaHJV7a=mc_kXeDcvuOSpSqamcA4a5jc_[
mc_kyp6uAyJE40UVuAQNEYzS1];mc_kwrB3ZoKf7OufTHWaHJV7a<mc_kXeDcvuOSpSqamcA4a5jc_
[mc_kyp6uAyJE40UVuAQNEYzS1+1];mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_Voyd06CWr20ad1V_wcUTVW[mc_VEXzFHKjFN87iiOtLrddNz[mc_kwrB3ZoKf7OufTHWaHJV7a]
]+=fabs(mc_VlnhKi82gfCLgumIqeduOq[mc_kwrB3ZoKf7OufTHWaHJV7a]*x[
mc_kyp6uAyJE40UVuAQNEYzS1]);}}for(mc_kyp6uAyJE40UVuAQNEYzS1=0;
mc_kyp6uAyJE40UVuAQNEYzS1<mc_FLkVm9soKgKChDbdna7u3o-mc_V0jiAH2gCJ_zYedoHqBU86;
mc_kyp6uAyJE40UVuAQNEYzS1++){const real_T mc_kg4CyRgbu6OdeewZOel7Qx=fabs(
mc_Fe6copTTRcKEayCm87ABO_[mc_kyp6uAyJE40UVuAQNEYzS1]);if(!(
mc_kg4CyRgbu6OdeewZOel7Qx<=2.0*mc_kEw8RhbAZIGdfeViKpSqbH*
mc_Voyd06CWr20ad1V_wcUTVW[mc_kyp6uAyJE40UVuAQNEYzS1]||
mc_kg4CyRgbu6OdeewZOel7Qx<=mc_FfDTppU8N_tOWuLK37x_08->mX[
mc_kyp6uAyJE40UVuAQNEYzS1])){return false;}}return true;}boolean_T
mc__TiJ6aR0GmK9WTqtHi6sGL(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const real_T mc_kUQBO1dSP8_IVqRAUx4R8G,
const size_t mc_V0jiAH2gCJ_zYedoHqBU86){size_t mc_kwrB3ZoKf7OufTHWaHJV7a;
size_t n=pm__hARyx1bZBxVj1boVQqdtV->mN;(void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=
0;mc_kwrB3ZoKf7OufTHWaHJV7a<n-mc_V0jiAH2gCJ_zYedoHqBU86;++
mc_kwrB3ZoKf7OufTHWaHJV7a){if(!(fabs(pm__hARyx1bZBxVj1boVQqdtV->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a])<=fabs(pm__YmIqNX3g5Sub1vKK1hZQF->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]*mc_kUQBO1dSP8_IVqRAUx4R8G))){return false;}}return
true;}real_T mc_kAKaeZRaJJO_jm2uJ1aLnZ(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,size_t mc_V0jiAH2gCJ_zYedoHqBU86){size_t
mc_kwrB3ZoKf7OufTHWaHJV7a,n=pm__hARyx1bZBxVj1boVQqdtV->mN;real_T*
mc_VAGK8ob2sQKOcm1T9oo3qq=pm__hARyx1bZBxVj1boVQqdtV->mX;real_T
mc__01SK3u3lG0GaLCTTSoVGO,mc_kPKKHEzx9slcbTkiKgmTSq=0.0;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n-
mc_V0jiAH2gCJ_zYedoHqBU86;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc__01SK3u3lG0GaLCTTSoVGO=mc_VAGK8ob2sQKOcm1T9oo3qq[mc_kwrB3ZoKf7OufTHWaHJV7a]
;mc_kPKKHEzx9slcbTkiKgmTSq+=mc__01SK3u3lG0GaLCTTSoVGO*
mc__01SK3u3lG0GaLCTTSoVGO;}mc_kPKKHEzx9slcbTkiKgmTSq=sqrt(
mc_kPKKHEzx9slcbTkiKgmTSq);return mc_kPKKHEzx9slcbTkiKgmTSq;}
