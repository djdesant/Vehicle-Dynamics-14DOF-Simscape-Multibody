#include "pm_std.h"
#include "pm_std.h"
#include "mc_std_fwd.h"
#include "mc_std_fwd.h"
#include "mc_std.h"
#include "pm_std.h"
#include "pm_std.h"
typedef enum{mc_FfS9gFGHqKt_fDwFfcldkw= -1,mc_FFaaXY_gkbSTcyLBvtfrzS,
mc_VUd8H_Dz0yp8cmQqTd7DxF,mc_kmVKy2ciwP4fcTEzXFmnvU,mc_VW_0L0rb93GgXq8_OmdwHv,
mc_kHoWGgwi3OdzaXvPvG1YY7,mc___D_4trEmdK8jyKCH6E_ac,mc_Fei8BCRUgBdwhDvvD5FrSo}
mc_kQtOKCqS08dIbumyDnHNDL;typedef struct mc_kv3fXx6PfXt7cekeoT00mk
mc_kgKqfPHHGatO_9OUxR4PRK;struct mc_kv3fXx6PfXt7cekeoT00mk{void*mPrivateData;
void(*mc_FapEct1OXaSugDZ6N_u_kA)(mc_kgKqfPHHGatO_9OUxR4PRK*,const char*
mc_FgZTwZqzhmd8haAibGoheR,const char*mc_k_4pzDDn_u0SjLvR9SBrIH);void(*
mc_FVdv01I3SEC4hD41rxmnRM)(mc_kgKqfPHHGatO_9OUxR4PRK*,const char*
mc_FgZTwZqzhmd8haAibGoheR,const char*mc_k_4pzDDn_u0SjLvR9SBrIH,real_T
mc__d1alWYexptL_X5HTFhbNK);void(*mc_kPHJTxMUjl8Oi1EQSHes2Q)(
mc_kgKqfPHHGatO_9OUxR4PRK*,const char*mc_FgZTwZqzhmd8haAibGoheR,const char*
mc_k_4pzDDn_u0SjLvR9SBrIH,const PmRealVector*mc__d1alWYexptL_X5HTFhbNK);void(*
mc__WEKdqi2uo0m_Dm8w8T_ZO)(mc_kgKqfPHHGatO_9OUxR4PRK*,const char*
mc_FgZTwZqzhmd8haAibGoheR,const char*mc_k_4pzDDn_u0SjLvR9SBrIH,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmRealVector*
mc__d1alWYexptL_X5HTFhbNK);};typedef struct mc__nZqLQp3m1lFaHyLAzyG2a
mc__39VLhR7TBCGYH016BQq8W;typedef struct mc__UzXDLpnAvdw_eUt0mYuul
mc_FJ2e3LJXmLlbhebizOW1SJ;typedef struct mc__sr5lnPbYjO_Wyo_mmPUmd
mc_Fw_IO5LchthA_LoeiSceRf;struct mc__sr5lnPbYjO_Wyo_mmPUmd{
mc_kgKqfPHHGatO_9OUxR4PRK*mc_kge3zWSlSoSRhTYHfGl24K;void(*
mc__6Do0w_54Hh7hDw5A7kAcK)(const mc__39VLhR7TBCGYH016BQq8W*
mc_kpyeXH2RWcWG_DVSgKEG_O,const PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,const
char*mc_FgZTwZqzhmd8haAibGoheR);};struct mc__nZqLQp3m1lFaHyLAzyG2a{
mc_FJ2e3LJXmLlbhebizOW1SJ*mPrivateData;const PmSparsityPattern*mPattern;
mc_Fw_IO5LchthA_LoeiSceRf mc_VZj1rpSBB0tKh5vOG9vb5j;void(*
mc_VF0z4xtGYCxzcHJNRB8l2n)(const mc__39VLhR7TBCGYH016BQq8W*
mc_kpyeXH2RWcWG_DVSgKEG_O,const PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,
PmRealVector*mc_V2mBNcV1EqCifyH9UdCbkF);void(*mc_kchvhvYJSIl4dyKnk7tfEC)(const
mc__39VLhR7TBCGYH016BQq8W*mc_kpyeXH2RWcWG_DVSgKEG_O,const PmRealVector*
mc__XfQXtB6cfd9fyc_v3eEup,PmRealVector*mc_V2mBNcV1EqCifyH9UdCbkF);void(*
mc_VLMY1ozRY0Kkj5P0kyXMgl)(const mc__39VLhR7TBCGYH016BQq8W*
mc_kpyeXH2RWcWG_DVSgKEG_O,const PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,
PmRealVector*mc_V2mBNcV1EqCifyH9UdCbkF);void(*mDestroy)(
mc__39VLhR7TBCGYH016BQq8W*mc_kpyeXH2RWcWG_DVSgKEG_O);};typedef struct
mc_VoVW1IGPg_WaWmrtPlXVfD mc_kxnFIpkyuc0YdXbZO41ABc;typedef struct
mc_FpSYgeBscUCg_qWX4io4Kb mc_FSKepYWjsK8mbHLmdHWO58;typedef struct
mc_F7TCRYOl9IpujDKe3vErcI mc_F3czdn9EwuxfaaYWgN0vfZ;struct
mc_F7TCRYOl9IpujDKe3vErcI{int32_T mc_ksngc9l6D5KFVXNgzwkok8[5];};
PMF_DEPLOY_STATIC mc_F3czdn9EwuxfaaYWgN0vfZ mc_FL6WWuhINbWMW5KJKs2y9t(void){
int32_T mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_F3czdn9EwuxfaaYWgN0vfZ
mc__1Zf2IciMRCub1vvbEr1C4;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<5;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc__1Zf2IciMRCub1vvbEr1C4 .mc_ksngc9l6D5KFVXNgzwkok8[mc_kwrB3ZoKf7OufTHWaHJV7a
]= -1;}return mc__1Zf2IciMRCub1vvbEr1C4;}struct mc_VoVW1IGPg_WaWmrtPlXVfD{
mc_FSKepYWjsK8mbHLmdHWO58*mPrivateData;mc_F3czdn9EwuxfaaYWgN0vfZ(*
mc__vHH72jqKt44cXWzB3_tSu)(const mc_kxnFIpkyuc0YdXbZO41ABc*
mc_kHt1ybY5z_OofadxN4AZsO);mc_kQtOKCqS08dIbumyDnHNDL(*mSolve)(const
mc_kxnFIpkyuc0YdXbZO41ABc*mc_kHt1ybY5z_OofadxN4AZsO,PmRealVector*
mc_VFDNUF6_N_t4Wu5qkxdJqD);void(*mc_FF_Aq2b8Cx_iduzooh_sWO)(const
mc_kxnFIpkyuc0YdXbZO41ABc*mc_kHt1ybY5z_OofadxN4AZsO,real_T
mc_kTckK8teUpOlhm8Ippu8XP);void(*mDestroy)(mc_kxnFIpkyuc0YdXbZO41ABc*
mc_kHt1ybY5z_OofadxN4AZsO);};typedef struct mc_kD0xfpE0MgxkYDG6tnWbJN
mc_kKrwrwNLgB_NYDY0UUZRVA;typedef struct mc_k577Fzud3mpCe91P_z0Qf_
mc_FuB6ZnvWHlGVe5AYB_qh1v;struct mc_kD0xfpE0MgxkYDG6tnWbJN{
mc_FuB6ZnvWHlGVe5AYB_qh1v*mPrivateData;mc_kxnFIpkyuc0YdXbZO41ABc*(*
mc_k_hVWBJWCUlCdPNZka5iZF)(const mc_kKrwrwNLgB_NYDY0UUZRVA*
mc__ZzBQ9ei49KTge3YSfX3g7,const mc__39VLhR7TBCGYH016BQq8W*
mc_kpyeXH2RWcWG_DVSgKEG_O);void(*mDestroy)(mc_kKrwrwNLgB_NYDY0UUZRVA*
mc__ZzBQ9ei49KTge3YSfX3g7);};typedef struct mc_FjeK_ZSfy_COYuwPPWwrm_
mc__3nzW_mY1qOqgXk2FmdyDG;typedef struct mc__WUe8IvZOGldjumXd_GpEC
mc_kTnNPenyhxlla9Uw7ULRfJ;typedef struct mc_FOtb37LSX8d5_5lHkmfBZj
mc_FfUgsrrKyC4CjixXpmLryh;struct mc_FOtb37LSX8d5_5lHkmfBZj{
mc_kgKqfPHHGatO_9OUxR4PRK*mc_kge3zWSlSoSRhTYHfGl24K;void(*
mc__6Do0w_54Hh7hDw5A7kAcK)(const mc__3nzW_mY1qOqgXk2FmdyDG*
mc_kpyeXH2RWcWG_DVSgKEG_O,const PmIntVector*mc_FHw707OTzcOEeaB2IM_AJQ,const
PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,const char*mc_FgZTwZqzhmd8haAibGoheR);}
;struct mc_FjeK_ZSfy_COYuwPPWwrm_{mc_kTnNPenyhxlla9Uw7ULRfJ*mPrivateData;const
PmSparsityPattern*mPattern;size_t mNumModes;mc_FfUgsrrKyC4CjixXpmLryh
mc_VZj1rpSBB0tKh5vOG9vb5j;void(*mc_VF0z4xtGYCxzcHJNRB8l2n)(const
mc__3nzW_mY1qOqgXk2FmdyDG*mc_kpyeXH2RWcWG_DVSgKEG_O,const PmIntVector*
mc_FHw707OTzcOEeaB2IM_AJQ,const PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,
PmRealVector*mc_V2mBNcV1EqCifyH9UdCbkF);void(*mc_kchvhvYJSIl4dyKnk7tfEC)(const
mc__3nzW_mY1qOqgXk2FmdyDG*mc_kpyeXH2RWcWG_DVSgKEG_O,const PmIntVector*
mc_FHw707OTzcOEeaB2IM_AJQ,const PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,
PmRealVector*mc_V2mBNcV1EqCifyH9UdCbkF);void(*mc_VLMY1ozRY0Kkj5P0kyXMgl)(const
mc__3nzW_mY1qOqgXk2FmdyDG*mc_kpyeXH2RWcWG_DVSgKEG_O,const PmIntVector*
mc_FHw707OTzcOEeaB2IM_AJQ,const PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,
PmRealVector*mc_V2mBNcV1EqCifyH9UdCbkF);void(*mc_VT_CRoRmbpWajqcrcvcctF)(const
mc__3nzW_mY1qOqgXk2FmdyDG*mc_kpyeXH2RWcWG_DVSgKEG_O,const PmIntVector*
mc_FHw707OTzcOEeaB2IM_AJQ,const PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,
PmIntVector*mc_V2mBNcV1EqCifyH9UdCbkF);void(*mDestroy)(
mc__3nzW_mY1qOqgXk2FmdyDG*mc_kpyeXH2RWcWG_DVSgKEG_O);};typedef struct
mc_kWpl_dOgP5SEdi8_h6_Q0f mc_FeVMxCfnPEW_Ya5WdW0ZiP;typedef struct
mc_VzTwbfayokK_ZT6nhi1fuh mc_kbq0rwTu6XGSZqa8cMRgbH;struct
mc_kWpl_dOgP5SEdi8_h6_Q0f{mc_kbq0rwTu6XGSZqa8cMRgbH*mPrivateData;
mc_kQtOKCqS08dIbumyDnHNDL(*mSolve)(const mc_FeVMxCfnPEW_Ya5WdW0ZiP*,
PmIntVector*,PmRealVector*);mc_F3czdn9EwuxfaaYWgN0vfZ(*
mc__vHH72jqKt44cXWzB3_tSu)(const mc_FeVMxCfnPEW_Ya5WdW0ZiP*
mc_kHt1ybY5z_OofadxN4AZsO);void(*mc_FF_Aq2b8Cx_iduzooh_sWO)(const
mc_FeVMxCfnPEW_Ya5WdW0ZiP*mc_kHt1ybY5z_OofadxN4AZsO,real_T
mc_kTckK8teUpOlhm8Ippu8XP);void(*mDestroy)(mc_FeVMxCfnPEW_Ya5WdW0ZiP*
mc_kHt1ybY5z_OofadxN4AZsO);};typedef struct mc__6rvEkBoZV0Khyk1wEL30q
mc_VLJsdw7KrQK_jqGzFmjnuT;typedef struct mc_VsuhjkXAxQOnYHPheaQV6t
mc_kAOZIOHKDP8Zh9U9Ca0DKK;struct mc__6rvEkBoZV0Khyk1wEL30q{
mc_kAOZIOHKDP8Zh9U9Ca0DKK*mPrivateData;mc_FeVMxCfnPEW_Ya5WdW0ZiP*(*
mc_k_hVWBJWCUlCdPNZka5iZF)(const mc_VLJsdw7KrQK_jqGzFmjnuT*
mc__ZzBQ9ei49KTge3YSfX3g7,const mc__3nzW_mY1qOqgXk2FmdyDG*
mc_kpyeXH2RWcWG_DVSgKEG_O);void(*mDestroy)(mc_VLJsdw7KrQK_jqGzFmjnuT*
mc__ZzBQ9ei49KTge3YSfX3g7);};
#include "mc_std_fwd.h"
mc_kKrwrwNLgB_NYDY0UUZRVA*mc__xbUGSPWT3_5jaEUjXpYZ_(PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY,const McLinearAlgebraFactory*
mc_Fiqi8a6cvxOLX1oR_MTbxh,size_t mc_kF77yGs8Y4pbZunORy8X8l,size_t
mc_F_FkJXxKCcG0fTwCI3XAqt,size_t mc_V0jiAH2gCJ_zYedoHqBU86,size_t
mc_VNsIi0F3TL_aeqk8IaSBnl,boolean_T mc_kw6NOvmP0mtTgTawDfvetp,boolean_T
mc_FDZq9eTGbfpXb97L46FmHM,IterationsLogCore*mc_FBc2dbX9MXKAd5WCw_3i1l);
#include "math.h"
#include "pm_std.h"
void pm_rv_equals_rv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void pm_VeeoZXnlJQ4u_112lGs8YD(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void pm_kpDvbw1GUlp4c5YdnW7V_w(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
pm_V2SLaBJy5WtXim9Lma9hfD(const PmCharVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmCharVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_FltUsml2sTlHZuCkbw_pdM(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_V8yYQkcd0vp_YaLM_nd75E(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm__P4MWKrtjzGPcercL4W7Fn(const
PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF);int_T pm_create_real_vector_fields(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmRealVector*pm_create_real_vector(size_t numElements,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmRealVector*pm_V_q_QnwoVVl6fHS_0pLvYo(const
PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_VeffaD_A8DxagH31Usec1H(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_destroy_real_vector(
PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
int_T pm_create_int_vector_fields(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t
size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmIntVector*pm_create_int_vector(
size_t numElements,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmIntVector*
pm__fSS_VMqhWlobeqe6mQF_x(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_V_eFnKjg5I4Uc1DwG4yU27(
PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_destroy_int_vector(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_bool_vector_fields(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmBoolVector*pm__jbisDMumXdocXANx5LhhY(size_t numElements,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kia_QXK77_xDg9M1NzHr3r(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_VuaGyqV_9K0Ia9Qgn65rsj(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmBoolVector*pm_kpRdzyG9L_8MV5lRovACCg(const
PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
int_T pm_create_char_vector_fields(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,
size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmCharVector*
pm_VUwRqkQ4oj4FjX20jJYKVB(size_t numElements,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_destroy_char_vector_fields(PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_Vb1pkQZ6CdGmbmIAJ3mnfZ(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_size_vector_fields(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSizeVector*pm_FZch3YyGWrOM_PQNdo7b2c(size_t numElements,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_FlA06lYLRAWkWmGBVmxE1a(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_kWBi8ZqmeopPhmEU9I2aNH(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_FJsPJplguVOI_1EYyUUvfK(const PmSizeVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);
boolean_T pm_kJR6lA3GKXdrdqFEbgLIwb(const PmSizeVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);
#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
size_t mc_VgM3Lx3pYgtLW13T1_txvP(const PmBoolVector*mc_VgJW5ZqpwPpuY1inYtaofQ)
;void mc_F4xMxEJX_DlUYXuaiDuSWS(const PmIntVector*mc_kyVj_uOQd__gg9_ljlZ_IY,
const PmRealVector*x,const PmRealVector*mc_FfDTppU8N_tOWuLK37x_08);void
mc_kQso3OAQDyxZaX0RF40IyE(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmIntVector*
mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_FCOSZaHMkXC6hyEys7zO54(const PmIntVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmIntVector*mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_V5jydIk5QzCRZTOycShqTL(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FvLmE29WKCKJfaZMHwg3g9(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const int32_T mc_kh0AzKGHcX8tfeDoNul_TU,
const int32_T mc__Oliq0seKPWShTNRpvAarb);void mc__pmVtsSuXZls_1NfvVprZ7(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH);void
mc_FR5FdJeEvDGGcyEVkxeE_x(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,boolean_T mc_FL_3a__K44dYi9fe74WHqt);
void mc_FK6EqkTbVFGMZ5QwXcurHx(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*mc_k8AO2tT20x0_cyxVp0ak3P);void mc_FioOBDJiFMpkWaAcUdBb1E(
const PmIntVector*mc_F6RwpxHXSXp7gDlfFRloPz,int32_T mc_kg4CyRgbu6OdeewZOel7Qx)
;void mc_kB1aHs1BVHG5YHNpmLLvkW(const PmBoolVector*mc_FrF2gTbWxox8geiSROFaFn,
const PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__vpsWwfj3fx1YDJlP_lHTd);void mc_V2P87Xoe0TGNeXNcn27vUJ(const PmBoolVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmBoolVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_VqP4HesDIf47bDn5teE2H2(const PmRealVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmRealVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_Vv4EJYeJDW0yZXiH42yCA_(const PmIntVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmIntVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_k0zonBZJC2K6baT1NXX1Qo(PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);size_t
mc_FLTxr_Wc1PKSeTxwfrcl5B(const PmBoolVector*mc__MqKyOds56_XeH9Iv3CTIL);void
mc_FX5UXdAa2flS_1wrwznTLh(const PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,const
PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE);size_t mc__RsEbvPhcXp6iqwYpH_OQY(const
PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);size_t mc__fQVSVSgEBG6fuximVFlkw(const
PmRealVector*mc_FawmFe5oOEC_cmkvZc1Kaa);size_t mc_FyLahU0kjICfba8O7mWi8Z(const
PmBoolVector*mc_FawmFe5oOEC_cmkvZc1Kaa);boolean_T mc___gjB_jZtTxReaWZSEiFdh(
const PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);boolean_T
mc_kNrn2e3NmaGNbmzmXpvCR0(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,int32_T
mc_kg4CyRgbu6OdeewZOel7Qx);boolean_T mc_kk65_VI6zC0mWHqRziXpjX(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_FGkd8Riw6p4eaDCAbwBVPv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FzkrLuS4xMOvaTv5dUw3j7(const
PmRealVector*x,real_T mc_VgJW5ZqpwPpuY1inYtaofQ);void mc_ks_PW4I7dwWbhXAWhHTUCI
(const PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc__w_RD4J1MZlqcL7as8FLdk(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V3CZVT50_V_xeia9SYYptc(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T a,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_VIFqLU9Z6UtwXDWPnvd_zg(const PmRealVector*x
,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_FBDi_PCg670TjHgJTNPcHr);void mc_VWnvos7Q548uVH7p0208jN(const PmRealVector*x
,const real_T a,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_V7hiVZfxKK0Uj9rPai4LYw(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
real_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VM9M6KxYTfKL_q4yuXmOnI(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const real_T mc_kcda_aHAM4WIXuM_xBDdLt)
;void mc_k4v_yYmXHgO1cqVdr5a500(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V2CDnBdRcOpuh1IyvRJzfi(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FNVEyWT4js4ebmsePvfFh2(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc__dsFCQJjA6p_j1tGhi2wWe(const PmRealVector*mc_VcZASgthsTt6dul8DlRWaw,real_T
mc_kcda_aHAM4WIXuM_xBDdLt);void mc_kUD9LJQRjT0FayfqpQrhnP(const PmBoolVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc__NFj_YrtCgd3dDixI_yrA7(const PmRealVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc__aNO1s5qwzt6fXwft5YgCz(const PmRealVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc_FzUHnQbqf_dRhX_X5DoWjW(const PmRealVector*
mc_VcZASgthsTt6dul8DlRWaw,size_t mc_kwrB3ZoKf7OufTHWaHJV7a,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_VTlukZ0iimdzge7aTGg7rl(const PmIntVector*
mc_VcZASgthsTt6dul8DlRWaw,int32_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_VDWYuA0FfQClgukbQcp3js(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc_k9wkPuvMCi4DY1yebDQPHf(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc__Nb_EyyxYi4ddPcS0H7Bot(const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH,const
PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);
void mc_k1sxUtEClkOZVuHMQ91JqD(const PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw,
boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VWloU5QD6gpaXeK8lmytFA(const
PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw);void mc_VQ1YWbKmkVC6YajZAyvmNH(const
PmBoolVector*x,size_t mc_kwrB3ZoKf7OufTHWaHJV7a,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc__uq8ZXcr_B_zgDxjibJDSi(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc_FnkaeEp6tpWlhHVVTP_g3C(const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);real_T mc_F1fvRD4xlFhBdyqJtcgdmn(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);real_T mc_kMPF5fccZd_3jHFMhUSro6(const
PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_kvxcenZbLm4dfenXL8jQAx(
const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_Vgo5SAIS_80_VXwmU7JogX
(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);void mc__25pQTf4VutiXiGTGQmvSU(
PmIntVector*mc__nP_wNlJUxWHWLytmZ4pL0,const PmIntVector*
mc_F6sy5cXK8JOKeiFBw6znSV);void mc__LECH_YE38C6YH4eYxxbSd(PmRealVector*
mc_VWoEnwEgWFpobmwHA1Qln5,const PmRealVector*mc_V_rxJBbuhqtwViRHFKhdGC,const
PmSparsityPattern*mc__Df1hQFzAY4fiLCvP0PV12);void mc_VMRKMuNLnDxXjaBiy1RcMD(
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc__04jybcJBjxwWX7Razqutu(const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const
PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*
mc_VDugqW09uVW_VLuociwzvN);void mc_VjtwQ41FT3hkaixcsQFmQH(const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*mc_VDugqW09uVW_VLuociwzvN);void mc_kM_Y9u9U2F_Cf9sWAtmMMu(
const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void mc__Xq_g76c6Y_K_PpYNKcquN(
const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const real_T*x);void mc_kXj99iXjC1CoZLWwPRH879(const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const
PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*
mc_FybTf2SinthyWqOxvPdJ5h,size_t mc_VVRAoFgW2Hphcy7H6H9Oh0);void
mc__75oXIAh8pt6cyvuqOckyG(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*mc_VxvrZHk3QVKlWycYYdZEat);void mc_kLGj2IdnGDG_YeEKAnMkUr(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FJN_drUOKh_igHJXVH7xls(
const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_V8ujEMKrDU8Q_mvu4yja1b,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
size_t mc_kyp6uAyJE40UVuAQNEYzS1,real_T mc_kcda_aHAM4WIXuM_xBDdLt);void
mc__WqQP6u7DtdYVDzUK5y971(const PmRealVector*mc_FBDi_PCg670TjHgJTNPcHr,const
PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_kc89O49Oe18lWqn1Nr_t61(const PmRealVector*mc_FrF2gTbWxox8geiSROFaFn,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__sdtG1OgJQtqcikFA20Doo);void mc_F4wnJSMmz0WHaHs2tnfI5y(const PmRealVector*
mc_FrF2gTbWxox8geiSROFaFn,const PmIntVector*mc__sdtG1OgJQtqcikFA20Doo,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE);void mc_VjzTgsx19j0KfHv6VXr4Mp(const
PmRealVector*a,const PmIntVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*
b);void mc_V_Fp06wJOBhXZyLbA5xU0r(const PmRealVector*a,const PmRealVector*b,
const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a);void mc_FuY0t5xEb5_QhDQFQ_TXtc(
const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_kkPot0UJiN_EX94QlR_mCs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,real_T x);void mc_kMo1w3ReRZGIdH5_MNwumc
(const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_VYxtXnMKT6hpb1FMldBDLs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void
mc_kl_UmQrKbdCajPyXz5nOIL(const PmRealVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void mc_k2E2oWXDqshMeuCQWrbaKT
(const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc_FBaB5196Xx0ohX_IWM5ypL(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T x);void
mc_F1CG0fHJYfd_ealLMx7Z7U(const PmIntVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void mc_krXbD205SBpghif1h1n_ei(
const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc__Qtfmi680EKpj1bOrIroGr(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void
mc__0IkRn0eQ9Wc_u8mCNbQDh(const PmIntVector*mc_VUELvXWGXPlKf1brR9MRC3,const
PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void mc__pbFNjwg_bCPdPFSjC2Wdv(
const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*
mc_FBOWjCOBM8SyhqFe64oqrx);void mc_VpjBXBa8TTCl_uBXYMLfxC(const PmBoolVector*
mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);
void mc__pFtu1g17h8ZaaZK4PpTkb(const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,
const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void
mc_kMScbNM1RKOTaD4QwTME8Y(const PmBoolVector*mc__1Zf2IciMRCub1vvbEr1C4,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmRealVector*
mc_VlnhKi82gfCLgumIqeduOq);void mc_Fbsqat6MlL0bjPHlNxax8t(const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FSAdXYnRP9pkfmWBYlMkJJ(
const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const PmSparsityPattern*
mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*mc_F8fT7naL9bOcimTADCVzTC);void
mc__NertSre4cWh_mN2RJ5UPq(const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*
mc_VCVhWy_VaDhraHrlfFWxBa);PmRealVector mc_VPFwoVShg1G3XTwou1_jbC(const
PmRealVector*mc_VgJW5ZqpwPpuY1inYtaofQ,size_t mc_Fyss_XM3F_C4dm6IKoDw4G,size_t
mc_Vs6xonQX17Krc5vXv8T_zq);
#include "mc_std.h"
#include "pm_std.h"
boolean_T mc_kOXeAPjCQDOxhXky_1MsMG(PmRealVector*mc__cCFC__DnidYg1kaNwxKZX,
PmRealVector*mc_VCpFjH0ABOdob1GmQhWaMX,PmRealVector*mc_Vg4sTMCV5NdPVemjId5WuL,
PmRealVector*mc__iaU8xWcwKOLgTx0Fs51s0,const PmSparsityPattern*
mc__67mUhUuDV4sharm2fatDC,const PmRealVector*mc_FfDTppU8N_tOWuLK37x_08,const
size_t mc_V0jiAH2gCJ_zYedoHqBU86);boolean_T mc__TiJ6aR0GmK9WTqtHi6sGL(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const real_T mc_kUQBO1dSP8_IVqRAUx4R8G,const size_t
mc_V0jiAH2gCJ_zYedoHqBU86);real_T mc_kAKaeZRaJJO_jm2uJ1aLnZ(const PmRealVector
*pm__hARyx1bZBxVj1boVQqdtV,size_t mc_V0jiAH2gCJ_zYedoHqBU86);
#include "pm_std.h"
#include "mc_std.h"
typedef struct mc_kuFewZAkeuOZeDrY1CHpwb{PmAllocator*mc_Ff9S1xA4Ip4ZXeljM4_eEa
;PmRealVector*mc_VYqd6LeSD8dlfue3FV8T4B;PmSparsityPattern*
mc_Fxu2SJtibqGKhm6_xP0GDv;PmRealVector*mc_V1oCOigUa6tEYmKEUR298W;
PmSparsityPattern*mc_VHcvbuqZh7xrauApSZRyRn;PmRealVector*
mc__Kx_oHE8xJCH_1TIAQ2ywB;PmSparsityPattern*mc__P00BEruj3tzfDaVMT2jjh;
McLinearAlgebra*mc_F0zpoJfX2j4sj9IETLJq8O;}mc_k3_ZK8MaYgORWqKNJacBmf;
mc_k3_ZK8MaYgORWqKNJacBmf*mc_VOoacG3k_IpceiQb3uHZPf(const PmSparsityPattern*
mc__67mUhUuDV4sharm2fatDC,const McLinearAlgebraFactory*
mc_Fiqi8a6cvxOLX1oR_MTbxh,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);void
mc__IMptWz5z5WDVHbZ2vXpck(mc_k3_ZK8MaYgORWqKNJacBmf*mc__d1alWYexptL_X5HTFhbNK)
;McLinearAlgebraStatus mc_VJOIHC89NCOCcmQgAS3kcX(PmRealVector*
mc_kr54pdOF7m03iip5bybdRd,PmRealVector*x,PmRealVector*
mc_Fe6copTTRcKEayCm87ABO_,mc_k3_ZK8MaYgORWqKNJacBmf*mc__d1alWYexptL_X5HTFhbNK,
const PmSparsityPattern*mc__67mUhUuDV4sharm2fatDC);struct
mc_k577Fzud3mpCe91P_z0Qf_{PmAllocator*mc_Ff9S1xA4Ip4ZXeljM4_eEa;const
McLinearAlgebraFactory*mc_FCqUeGcaJ6tVXTKxCgh17W;size_t
mc_k3YP_F9lOAp7Vy_38IwwJz;size_t mc_F5toqgHxv5CbgmiMEeN1Ri;size_t
mc_VK6xPezuw04diXgfU3wa_1;size_t mc__UQB2tbdDSCFWu8zfrD8xX;boolean_T
mc__NTUGzBJhMGgfiDsBm1dv3;boolean_T mc__CVAW4jtu3O3Xywuw1sG4q;
IterationsLogCore*mc_kV0hFh2l2Wx4dit9DlxIa_;};struct mc_FpSYgeBscUCg_qWX4io4Kb
{const mc__39VLhR7TBCGYH016BQq8W*mc_Vu8wy9IGEVWgiDu5nL3zwQ;boolean_T
mc_Fmz7kQg1at8Yayod8iYfEi;real_T mFactor;mc_FuB6ZnvWHlGVe5AYB_qh1v
mc_VPnByizXfG86dX_49PzmU_;PmRealVector*mc_V0UUcX83oJCyVDQrAdN4ai;PmRealVector*
mc_Vb5HRZnh56C1XuonP51flj;PmRealVector*mc_kzfdQnEuRq8Jbax78su1Qh;PmRealVector*
mc_VVzEhveeLp_3VmGl_1W8fn;PmRealVector*mc__HKFYzrt3RxcZqzFAcqapU;PmRealVector*
mc_F1q2EnR2giSTdeJuEnNmm3;PmRealVector*mc_Fso2jnUIWUtLfuwv9vZA2P;
mc_k3_ZK8MaYgORWqKNJacBmf*mc_kXZB7gLIpzGRgDLMUplrVP;McLinearAlgebra*
mc_F0zpoJfX2j4sj9IETLJq8O;};static mc_F3czdn9EwuxfaaYWgN0vfZ
mc_kPu7ckybzItljXuumjVaxs(const mc_kxnFIpkyuc0YdXbZO41ABc*
mc_V8a_FQ2T6YWLgu_s5UfAPx){mc_F3czdn9EwuxfaaYWgN0vfZ mc_kDh9Sdqtd1dhZLBqs4W1eB
;if(mc_V8a_FQ2T6YWLgu_s5UfAPx->mPrivateData->mc_Fmz7kQg1at8Yayod8iYfEi){
mc_kDh9Sdqtd1dhZLBqs4W1eB=mc_FL6WWuhINbWMW5KJKs2y9t();}else{PmIntVector
mc_kJ5kaOZGlN4vYDtAnAgF5u;mc_kJ5kaOZGlN4vYDtAnAgF5u.mN=5;
mc_kJ5kaOZGlN4vYDtAnAgF5u.mX= &(mc_kDh9Sdqtd1dhZLBqs4W1eB.
mc_ksngc9l6D5KFVXNgzwkok8[0]);mc_F4xMxEJX_DlUYXuaiDuSWS(&
mc_kJ5kaOZGlN4vYDtAnAgF5u,mc_V8a_FQ2T6YWLgu_s5UfAPx->mPrivateData->
mc_Vb5HRZnh56C1XuonP51flj,mc_V8a_FQ2T6YWLgu_s5UfAPx->mPrivateData->
mc_F1q2EnR2giSTdeJuEnNmm3);}return mc_kDh9Sdqtd1dhZLBqs4W1eB;}static void
mc__4_Ms9rjBntfaqEEDoFhYk(const mc_kxnFIpkyuc0YdXbZO41ABc*
mc_V8a_FQ2T6YWLgu_s5UfAPx,real_T mc_kTckK8teUpOlhm8Ippu8XP){
mc_V8a_FQ2T6YWLgu_s5UfAPx->mPrivateData->mFactor=mc_kTckK8teUpOlhm8Ippu8XP;}
static mc_kQtOKCqS08dIbumyDnHNDL mc___FEkSv9KZtwaqN9uPeqOD(const
mc_kxnFIpkyuc0YdXbZO41ABc*mc_V8a_FQ2T6YWLgu_s5UfAPx,PmRealVector*x){
mc_FSKepYWjsK8mbHLmdHWO58*mc__jUbZ5TudDGfVmrpB7MnwY=mc_V8a_FQ2T6YWLgu_s5UfAPx
->mPrivateData;size_t mc_kF77yGs8Y4pbZunORy8X8l=mc__jUbZ5TudDGfVmrpB7MnwY->
mc_VPnByizXfG86dX_49PzmU_.mc_k3YP_F9lOAp7Vy_38IwwJz;size_t
mc_F_FkJXxKCcG0fTwCI3XAqt=mc__jUbZ5TudDGfVmrpB7MnwY->mc_VPnByizXfG86dX_49PzmU_
.mc_F5toqgHxv5CbgmiMEeN1Ri;size_t mc_V0jiAH2gCJ_zYedoHqBU86=
mc__jUbZ5TudDGfVmrpB7MnwY->mc_VPnByizXfG86dX_49PzmU_.mc_VK6xPezuw04diXgfU3wa_1
;boolean_T mc_kw6NOvmP0mtTgTawDfvetp=mc__jUbZ5TudDGfVmrpB7MnwY->
mc_VPnByizXfG86dX_49PzmU_.mc__NTUGzBJhMGgfiDsBm1dv3;boolean_T
mc_FDZq9eTGbfpXb97L46FmHM=mc__jUbZ5TudDGfVmrpB7MnwY->mc_VPnByizXfG86dX_49PzmU_
.mc__CVAW4jtu3O3Xywuw1sG4q;real_T mc_kEw8RhbAZIGdfeViKpSqbH=pmf_get_eps();
real_T mc_kQETvtDt41__X58qWH6l_r=0.333;real_T mc_FshATkJvqFWGdymV9P0N8h=
mc__jUbZ5TudDGfVmrpB7MnwY->mFactor;PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL=
mc__jUbZ5TudDGfVmrpB7MnwY->mc_V0UUcX83oJCyVDQrAdN4ai;PmRealVector*
mc_Fe6copTTRcKEayCm87ABO_=mc__jUbZ5TudDGfVmrpB7MnwY->mc_Vb5HRZnh56C1XuonP51flj
;PmRealVector*mc_F4Z2hspK_YCRc9oAiI1Kq0=mc__jUbZ5TudDGfVmrpB7MnwY->
mc_VVzEhveeLp_3VmGl_1W8fn;PmRealVector*mc_kR3Z4Y4Z1khGfi2iVdFGa1=
mc__jUbZ5TudDGfVmrpB7MnwY->mc__HKFYzrt3RxcZqzFAcqapU;PmRealVector*
mc_FfDTppU8N_tOWuLK37x_08=mc__jUbZ5TudDGfVmrpB7MnwY->mc_F1q2EnR2giSTdeJuEnNmm3
;PmRealVector*mc_FCduuok2Ux0jeaK_PqTq_B=mc__jUbZ5TudDGfVmrpB7MnwY->
mc_Fso2jnUIWUtLfuwv9vZA2P;const mc__39VLhR7TBCGYH016BQq8W*
mc_VHx3JOvtgIK3VPttL15wzm=mc__jUbZ5TudDGfVmrpB7MnwY->mc_Vu8wy9IGEVWgiDu5nL3zwQ
;const PmSparsityPattern*mc__67mUhUuDV4sharm2fatDC=(mc_VHx3JOvtgIK3VPttL15wzm)
->mPattern;size_t mc_FPwVUAP_do0ogeBnBjppr5=0;size_t mc__vlXGYM3ygGsW1JYzuRIam
=0;size_t mc_FGgqZZPpym44Xe_parMHOk=0;real_T mc_VEIa1dy0DH0AdyZ2krsJ_6=0.0;
real_T mc_FLG_Ai7ECNhfc1enuORKk1=0.0;real_T mc_VapJJUuOEMKfZ10rTy1oaU=0.0;
real_T mc_k7RVes5oHPO2Yi5DMSKkeo=0.0;boolean_T mc_FvMxplj_xrSuWHxIw_ohwW=false
;boolean_T mc_FyYoN69Nl3Opjy91htmdy_=false;boolean_T mc_V7U6X4ED_OdibLjfa2aNzi
=false;boolean_T mc_kY4TOyQPk__a_TPRoy3CNw=false;size_t
mc__1Zf2IciMRCub1vvbEr1C4=0;size_t mc_F5hn__D9gkdVfLJThV_Gcu=0;
mc_kQtOKCqS08dIbumyDnHNDL mc_k4M7bSEmThKJbirXUDQgS6=mc_FfS9gFGHqKt_fDwFfcldkw;
int32_T mc_FQ7VXQGcxAWQhi22ldg8Cy=0;boolean_T mc_VzZ8gjax5SOXfDQklzR6KS;(void)
0;;mc__jUbZ5TudDGfVmrpB7MnwY->mc_Fmz7kQg1at8Yayod8iYfEi=false;pm_rv_equals_rv(
mc_FzyLWRgau0pMYq2XSI3ETL,x);(mc_VHx3JOvtgIK3VPttL15wzm)->
mc_VF0z4xtGYCxzcHJNRB8l2n((mc_VHx3JOvtgIK3VPttL15wzm),
mc_FzyLWRgau0pMYq2XSI3ETL,mc_Fe6copTTRcKEayCm87ABO_);mc_VEIa1dy0DH0AdyZ2krsJ_6
=mc_kAKaeZRaJJO_jm2uJ1aLnZ(mc_Fe6copTTRcKEayCm87ABO_,mc_F5hn__D9gkdVfLJThV_Gcu
);(mc_VHx3JOvtgIK3VPttL15wzm)->mc_VLMY1ozRY0Kkj5P0kyXMgl((
mc_VHx3JOvtgIK3VPttL15wzm),mc_FzyLWRgau0pMYq2XSI3ETL,mc_FfDTppU8N_tOWuLK37x_08
);mc_V7hiVZfxKK0Uj9rPai4LYw(mc_FfDTppU8N_tOWuLK37x_08,
mc_FshATkJvqFWGdymV9P0N8h);mc_FPwVUAP_do0ogeBnBjppr5=0;
mc__vlXGYM3ygGsW1JYzuRIam=0;mc_FvMxplj_xrSuWHxIw_ohwW=false;while((
mc_FPwVUAP_do0ogeBnBjppr5<mc_kF77yGs8Y4pbZunORy8X8l)&&(
mc_kw6NOvmP0mtTgTawDfvetp||!mc__TiJ6aR0GmK9WTqtHi6sGL(
mc_Fe6copTTRcKEayCm87ABO_,mc_FfDTppU8N_tOWuLK37x_08,1.0,
mc_F5hn__D9gkdVfLJThV_Gcu)||mc_FvMxplj_xrSuWHxIw_ohwW)){
mc_FPwVUAP_do0ogeBnBjppr5++;if(mc_kY4TOyQPk__a_TPRoy3CNw){
mc_F5hn__D9gkdVfLJThV_Gcu=mc_V0jiAH2gCJ_zYedoHqBU86;}mc_FLG_Ai7ECNhfc1enuORKk1
=mc_VEIa1dy0DH0AdyZ2krsJ_6;mc_V7hiVZfxKK0Uj9rPai4LYw(mc_Fe6copTTRcKEayCm87ABO_
,-1.0);(mc_VHx3JOvtgIK3VPttL15wzm)->mc_kchvhvYJSIl4dyKnk7tfEC((
mc_VHx3JOvtgIK3VPttL15wzm),mc_FzyLWRgau0pMYq2XSI3ETL,mc_FCduuok2Ux0jeaK_PqTq_B
);mc__1Zf2IciMRCub1vvbEr1C4=((((mc_V8a_FQ2T6YWLgu_s5UfAPx)->mPrivateData)->
mc_F0zpoJfX2j4sj9IETLJq8O))->mFactor((((mc_V8a_FQ2T6YWLgu_s5UfAPx)->
mPrivateData)->mc_F0zpoJfX2j4sj9IETLJq8O),(mc_FCduuok2Ux0jeaK_PqTq_B)->mX);if(
mc__1Zf2IciMRCub1vvbEr1C4==MC_LA_OK){mc__1Zf2IciMRCub1vvbEr1C4=((((
mc_V8a_FQ2T6YWLgu_s5UfAPx)->mPrivateData)->mc_F0zpoJfX2j4sj9IETLJq8O))->mSolve
((((mc_V8a_FQ2T6YWLgu_s5UfAPx)->mPrivateData)->mc_F0zpoJfX2j4sj9IETLJq8O),(
mc_FCduuok2Ux0jeaK_PqTq_B)->mX,(mc_kR3Z4Y4Z1khGfi2iVdFGa1)->mX,(
mc_Fe6copTTRcKEayCm87ABO_)->mX);}else{mc__vlXGYM3ygGsW1JYzuRIam++;if(
mc_FDZq9eTGbfpXb97L46FmHM){mc_k3_ZK8MaYgORWqKNJacBmf*mc__d1alWYexptL_X5HTFhbNK
=mc__jUbZ5TudDGfVmrpB7MnwY->mc_kXZB7gLIpzGRgDLMUplrVP;if((
mc_VHx3JOvtgIK3VPttL15wzm)->mc_VZj1rpSBB0tKh5vOG9vb5j.
mc_kge3zWSlSoSRhTYHfGl24K){(mc_VHx3JOvtgIK3VPttL15wzm)->
mc_VZj1rpSBB0tKh5vOG9vb5j.mc_kge3zWSlSoSRhTYHfGl24K->mc_FapEct1OXaSugDZ6N_u_kA
((mc_VHx3JOvtgIK3VPttL15wzm)->mc_VZj1rpSBB0tKh5vOG9vb5j.
mc_kge3zWSlSoSRhTYHfGl24K,"newton_solver_ftol",
"Singular Jacobian. Trying to perturb");};mc__1Zf2IciMRCub1vvbEr1C4=
mc_VJOIHC89NCOCcmQgAS3kcX(mc_FCduuok2Ux0jeaK_PqTq_B,mc_kR3Z4Y4Z1khGfi2iVdFGa1,
mc_Fe6copTTRcKEayCm87ABO_,mc__d1alWYexptL_X5HTFhbNK,mc__67mUhUuDV4sharm2fatDC)
;}else{(void)0;;mc__1Zf2IciMRCub1vvbEr1C4=MC_LA_ERROR;}}if(
mc__1Zf2IciMRCub1vvbEr1C4!=MC_LA_OK){return mc_kmVKy2ciwP4fcTEzXFmnvU;}
mc_VzZ8gjax5SOXfDQklzR6KS=false;mc_k7RVes5oHPO2Yi5DMSKkeo=1.0;for(
mc_FGgqZZPpym44Xe_parMHOk=0;mc_FGgqZZPpym44Xe_parMHOk<
mc_F_FkJXxKCcG0fTwCI3XAqt;mc_FGgqZZPpym44Xe_parMHOk++){boolean_T
mc_kVbcMTCxuw8xjDDEWPvKhu=false;pm_rv_equals_rv(mc_F4Z2hspK_YCRc9oAiI1Kq0,
mc_FzyLWRgau0pMYq2XSI3ETL);mc_V3CZVT50_V_xeia9SYYptc(mc_F4Z2hspK_YCRc9oAiI1Kq0
,mc_k7RVes5oHPO2Yi5DMSKkeo,mc_kR3Z4Y4Z1khGfi2iVdFGa1);if(!
mc_kw6NOvmP0mtTgTawDfvetp&&pm_FltUsml2sTlHZuCkbw_pdM(mc_F4Z2hspK_YCRc9oAiI1Kq0
,mc_FzyLWRgau0pMYq2XSI3ETL)){mc_V3CZVT50_V_xeia9SYYptc(
mc_F4Z2hspK_YCRc9oAiI1Kq0,1.0,mc_kR3Z4Y4Z1khGfi2iVdFGa1);
mc_kVbcMTCxuw8xjDDEWPvKhu=true;}(mc_VHx3JOvtgIK3VPttL15wzm)->
mc_VF0z4xtGYCxzcHJNRB8l2n((mc_VHx3JOvtgIK3VPttL15wzm),
mc_F4Z2hspK_YCRc9oAiI1Kq0,mc_Fe6copTTRcKEayCm87ABO_);mc_VapJJUuOEMKfZ10rTy1oaU
=mc_kAKaeZRaJJO_jm2uJ1aLnZ(mc_Fe6copTTRcKEayCm87ABO_,mc_F5hn__D9gkdVfLJThV_Gcu
);if(mc_VapJJUuOEMKfZ10rTy1oaU<mc_VEIa1dy0DH0AdyZ2krsJ_6||
mc_kVbcMTCxuw8xjDDEWPvKhu){mc_VzZ8gjax5SOXfDQklzR6KS=true;break;}
mc_k7RVes5oHPO2Yi5DMSKkeo/=2.0;}if(!mc_VzZ8gjax5SOXfDQklzR6KS&&
mc_V0jiAH2gCJ_zYedoHqBU86>0){mc_kY4TOyQPk__a_TPRoy3CNw=true;}pm_rv_equals_rv(
mc_FzyLWRgau0pMYq2XSI3ETL,mc_F4Z2hspK_YCRc9oAiI1Kq0);mc_VEIa1dy0DH0AdyZ2krsJ_6
=mc_VapJJUuOEMKfZ10rTy1oaU;(mc_VHx3JOvtgIK3VPttL15wzm)->
mc_VLMY1ozRY0Kkj5P0kyXMgl((mc_VHx3JOvtgIK3VPttL15wzm),
mc_FzyLWRgau0pMYq2XSI3ETL,mc_FfDTppU8N_tOWuLK37x_08);mc_V7hiVZfxKK0Uj9rPai4LYw
(mc_FfDTppU8N_tOWuLK37x_08,mc_FshATkJvqFWGdymV9P0N8h);if((
mc_VHx3JOvtgIK3VPttL15wzm)->mc_VZj1rpSBB0tKh5vOG9vb5j.
mc__6Do0w_54Hh7hDw5A7kAcK){(mc_VHx3JOvtgIK3VPttL15wzm)->
mc_VZj1rpSBB0tKh5vOG9vb5j.mc__6Do0w_54Hh7hDw5A7kAcK(mc_VHx3JOvtgIK3VPttL15wzm,
mc_FzyLWRgau0pMYq2XSI3ETL,"newton_solver_ftol");};mc_FvMxplj_xrSuWHxIw_ohwW=((
mc_VEIa1dy0DH0AdyZ2krsJ_6<mc_kQETvtDt41__X58qWH6l_r*mc_FLG_Ai7ECNhfc1enuORKk1)
&&(!mc__TiJ6aR0GmK9WTqtHi6sGL(mc_Fe6copTTRcKEayCm87ABO_,
mc_FfDTppU8N_tOWuLK37x_08,mc_kEw8RhbAZIGdfeViKpSqbH,mc_F5hn__D9gkdVfLJThV_Gcu)
));if(mc__jUbZ5TudDGfVmrpB7MnwY->mc_VPnByizXfG86dX_49PzmU_.
mc_kV0hFh2l2Wx4dit9DlxIa_!=NULL){if(mc_FQ7VXQGcxAWQhi22ldg8Cy==0&&
mc__TiJ6aR0GmK9WTqtHi6sGL(mc_Fe6copTTRcKEayCm87ABO_,mc_FfDTppU8N_tOWuLK37x_08,
1.0,mc_F5hn__D9gkdVfLJThV_Gcu)){mc_FQ7VXQGcxAWQhi22ldg8Cy=(int32_T)
mc_FPwVUAP_do0ogeBnBjppr5;break;}else if(mc_FQ7VXQGcxAWQhi22ldg8Cy==0&&
mc_kOXeAPjCQDOxhXky_1MsMG(mc__jUbZ5TudDGfVmrpB7MnwY->mc_kzfdQnEuRq8Jbax78su1Qh
,mc_Fe6copTTRcKEayCm87ABO_,mc_FzyLWRgau0pMYq2XSI3ETL,mc_FCduuok2Ux0jeaK_PqTq_B
,mc__67mUhUuDV4sharm2fatDC,mc_FfDTppU8N_tOWuLK37x_08,mc_F5hn__D9gkdVfLJThV_Gcu
)){mc_FQ7VXQGcxAWQhi22ldg8Cy=(int32_T)mc_FPwVUAP_do0ogeBnBjppr5;
mc__jUbZ5TudDGfVmrpB7MnwY->mc_VPnByizXfG86dX_49PzmU_.mc_kV0hFh2l2Wx4dit9DlxIa_
->mPrecisionMet=false;break;}}}pm_rv_equals_rv(x,mc_FzyLWRgau0pMYq2XSI3ETL);if
(mc_kw6NOvmP0mtTgTawDfvetp){mc_FyYoN69Nl3Opjy91htmdy_=true;}else if(
mc__TiJ6aR0GmK9WTqtHi6sGL(mc_Fe6copTTRcKEayCm87ABO_,mc_FfDTppU8N_tOWuLK37x_08,
1.0,mc_F5hn__D9gkdVfLJThV_Gcu)){mc_FyYoN69Nl3Opjy91htmdy_=true;}else{
mc_FyYoN69Nl3Opjy91htmdy_=mc_kOXeAPjCQDOxhXky_1MsMG(mc__jUbZ5TudDGfVmrpB7MnwY
->mc_kzfdQnEuRq8Jbax78su1Qh,mc_Fe6copTTRcKEayCm87ABO_,
mc_FzyLWRgau0pMYq2XSI3ETL,mc_FCduuok2Ux0jeaK_PqTq_B,mc__67mUhUuDV4sharm2fatDC,
mc_FfDTppU8N_tOWuLK37x_08,mc_F5hn__D9gkdVfLJThV_Gcu);}if(
mc_FyYoN69Nl3Opjy91htmdy_){mc__jUbZ5TudDGfVmrpB7MnwY->
mc_Fmz7kQg1at8Yayod8iYfEi=true;if(mc__jUbZ5TudDGfVmrpB7MnwY->
mc_VPnByizXfG86dX_49PzmU_.mc_kV0hFh2l2Wx4dit9DlxIa_!=NULL){if(
mc_FQ7VXQGcxAWQhi22ldg8Cy==0){mc__jUbZ5TudDGfVmrpB7MnwY->
mc_VPnByizXfG86dX_49PzmU_.mc_kV0hFh2l2Wx4dit9DlxIa_->mNumIters= -1;
mc__jUbZ5TudDGfVmrpB7MnwY->mc_VPnByizXfG86dX_49PzmU_.mc_kV0hFh2l2Wx4dit9DlxIa_
->mConvergence=false;}else if(mc__jUbZ5TudDGfVmrpB7MnwY->
mc_VPnByizXfG86dX_49PzmU_.mc_kV0hFh2l2Wx4dit9DlxIa_->mNumIters>=0&&
mc_FQ7VXQGcxAWQhi22ldg8Cy>mc__jUbZ5TudDGfVmrpB7MnwY->mc_VPnByizXfG86dX_49PzmU_
.mc_kV0hFh2l2Wx4dit9DlxIa_->mNumIters){mc__jUbZ5TudDGfVmrpB7MnwY->
mc_VPnByizXfG86dX_49PzmU_.mc_kV0hFh2l2Wx4dit9DlxIa_->mNumIters=
mc_FQ7VXQGcxAWQhi22ldg8Cy;mc__jUbZ5TudDGfVmrpB7MnwY->mc_VPnByizXfG86dX_49PzmU_
.mc_kV0hFh2l2Wx4dit9DlxIa_->mConvergence=true;}}return
mc_FFaaXY_gkbSTcyLBvtfrzS;}else{mc_V7U6X4ED_OdibLjfa2aNzi=((
mc_FPwVUAP_do0ogeBnBjppr5>2)&&(mc__vlXGYM3ygGsW1JYzuRIam*2>=
mc_FPwVUAP_do0ogeBnBjppr5));return mc_V7U6X4ED_OdibLjfa2aNzi?
mc_kmVKy2ciwP4fcTEzXFmnvU:mc_VW_0L0rb93GgXq8_OmdwHv;}}static void
mc_VfIubPxnSq_mXuL8YtnNNe(mc_kxnFIpkyuc0YdXbZO41ABc*mc_V8a_FQ2T6YWLgu_s5UfAPx)
{PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY=mc_V8a_FQ2T6YWLgu_s5UfAPx->mPrivateData
->mc_VPnByizXfG86dX_49PzmU_.mc_Ff9S1xA4Ip4ZXeljM4_eEa;McLinearAlgebra*
mc__cs_l0pvGGWCXDgz1TCAlt=mc_V8a_FQ2T6YWLgu_s5UfAPx->mPrivateData->
mc_F0zpoJfX2j4sj9IETLJq8O;pm_destroy_real_vector(mc_V8a_FQ2T6YWLgu_s5UfAPx->
mPrivateData->mc_V0UUcX83oJCyVDQrAdN4ai,pm_FbYb_iLqY2hwZTVlVaiqJY);
pm_destroy_real_vector(mc_V8a_FQ2T6YWLgu_s5UfAPx->mPrivateData->
mc_Vb5HRZnh56C1XuonP51flj,pm_FbYb_iLqY2hwZTVlVaiqJY);pm_destroy_real_vector(
mc_V8a_FQ2T6YWLgu_s5UfAPx->mPrivateData->mc_kzfdQnEuRq8Jbax78su1Qh,
pm_FbYb_iLqY2hwZTVlVaiqJY);pm_destroy_real_vector(mc_V8a_FQ2T6YWLgu_s5UfAPx->
mPrivateData->mc_VVzEhveeLp_3VmGl_1W8fn,pm_FbYb_iLqY2hwZTVlVaiqJY);
pm_destroy_real_vector(mc_V8a_FQ2T6YWLgu_s5UfAPx->mPrivateData->
mc__HKFYzrt3RxcZqzFAcqapU,pm_FbYb_iLqY2hwZTVlVaiqJY);pm_destroy_real_vector(
mc_V8a_FQ2T6YWLgu_s5UfAPx->mPrivateData->mc_F1q2EnR2giSTdeJuEnNmm3,
pm_FbYb_iLqY2hwZTVlVaiqJY);pm_destroy_real_vector(mc_V8a_FQ2T6YWLgu_s5UfAPx->
mPrivateData->mc_Fso2jnUIWUtLfuwv9vZA2P,pm_FbYb_iLqY2hwZTVlVaiqJY);if(
mc_V8a_FQ2T6YWLgu_s5UfAPx->mPrivateData->mc_VPnByizXfG86dX_49PzmU_.
mc__CVAW4jtu3O3Xywuw1sG4q){mc__IMptWz5z5WDVHbZ2vXpck(mc_V8a_FQ2T6YWLgu_s5UfAPx
->mPrivateData->mc_kXZB7gLIpzGRgDLMUplrVP);}else{(void)0;;}
mc__cs_l0pvGGWCXDgz1TCAlt->mDestructor(mc__cs_l0pvGGWCXDgz1TCAlt);{void*
mc_kk06poLCQlh5i5Yv6GSh7e=(mc_V8a_FQ2T6YWLgu_s5UfAPx->mPrivateData);if(
mc_kk06poLCQlh5i5Yv6GSh7e!=0){(pm_FbYb_iLqY2hwZTVlVaiqJY)->mFreeFcn(
pm_FbYb_iLqY2hwZTVlVaiqJY,mc_kk06poLCQlh5i5Yv6GSh7e);}};{void*
mc_kk06poLCQlh5i5Yv6GSh7e=(mc_V8a_FQ2T6YWLgu_s5UfAPx);if(
mc_kk06poLCQlh5i5Yv6GSh7e!=0){(pm_FbYb_iLqY2hwZTVlVaiqJY)->mFreeFcn(
pm_FbYb_iLqY2hwZTVlVaiqJY,mc_kk06poLCQlh5i5Yv6GSh7e);}};}static
mc_kxnFIpkyuc0YdXbZO41ABc*mc__tPeUeveyLKtbPsJ38Xq7C(const
mc_kKrwrwNLgB_NYDY0UUZRVA*mc__RtkHrrPEelBbDRCt5cBnV,const
mc__39VLhR7TBCGYH016BQq8W*mc_VkOVRwyffyOPbanx3qI3TI){PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY=mc__RtkHrrPEelBbDRCt5cBnV->mPrivateData->
mc_Ff9S1xA4Ip4ZXeljM4_eEa;const McLinearAlgebraFactory*
mc_FzcJQ1Jxl1hoZDRi6_VHkF=mc__RtkHrrPEelBbDRCt5cBnV->mPrivateData->
mc_FCqUeGcaJ6tVXTKxCgh17W;mc_kxnFIpkyuc0YdXbZO41ABc*mc_V8a_FQ2T6YWLgu_s5UfAPx=
(mc_kxnFIpkyuc0YdXbZO41ABc*)((pm_FbYb_iLqY2hwZTVlVaiqJY)->mCallocFcn((
pm_FbYb_iLqY2hwZTVlVaiqJY),(sizeof(mc_kxnFIpkyuc0YdXbZO41ABc)),(1)));
mc_FSKepYWjsK8mbHLmdHWO58*mc__jUbZ5TudDGfVmrpB7MnwY=(mc_FSKepYWjsK8mbHLmdHWO58
*)((pm_FbYb_iLqY2hwZTVlVaiqJY)->mCallocFcn((pm_FbYb_iLqY2hwZTVlVaiqJY),(sizeof
(mc_FSKepYWjsK8mbHLmdHWO58)),(1)));const PmSparsityPattern*
mc__67mUhUuDV4sharm2fatDC=mc_VkOVRwyffyOPbanx3qI3TI->mPattern;size_t
mc_Fol7VPru5_d7diNJkJAWvC=mc__67mUhUuDV4sharm2fatDC->mNumRow;size_t
mc__bVyeWKHNFpu_5gxm_rTwS=mc__67mUhUuDV4sharm2fatDC->mNumCol;size_t
mc_Vq3VczAgWO8XYqVdDRv4Kb=((size_t)(mc__67mUhUuDV4sharm2fatDC)->mJc[(
mc__67mUhUuDV4sharm2fatDC)->mNumCol]);size_t mc__QyEMu_QAQK7YiC6_70ZGE;int32_T
mc__1Zf2IciMRCub1vvbEr1C4=0;mc__jUbZ5TudDGfVmrpB7MnwY->
mc_Vu8wy9IGEVWgiDu5nL3zwQ=mc_VkOVRwyffyOPbanx3qI3TI;mc__jUbZ5TudDGfVmrpB7MnwY
->mc_Fmz7kQg1at8Yayod8iYfEi=true;mc__jUbZ5TudDGfVmrpB7MnwY->
mc_VPnByizXfG86dX_49PzmU_= *(mc__RtkHrrPEelBbDRCt5cBnV->mPrivateData);
mc__jUbZ5TudDGfVmrpB7MnwY->mFactor=1.0;mc__jUbZ5TudDGfVmrpB7MnwY->
mc_V0UUcX83oJCyVDQrAdN4ai=pm_create_real_vector(mc__bVyeWKHNFpu_5gxm_rTwS,
pm_FbYb_iLqY2hwZTVlVaiqJY);mc__jUbZ5TudDGfVmrpB7MnwY->
mc_Vb5HRZnh56C1XuonP51flj=pm_create_real_vector(mc_Fol7VPru5_d7diNJkJAWvC,
pm_FbYb_iLqY2hwZTVlVaiqJY);mc__jUbZ5TudDGfVmrpB7MnwY->
mc_kzfdQnEuRq8Jbax78su1Qh=pm_create_real_vector(mc_Fol7VPru5_d7diNJkJAWvC,
pm_FbYb_iLqY2hwZTVlVaiqJY);mc__jUbZ5TudDGfVmrpB7MnwY->
mc_VVzEhveeLp_3VmGl_1W8fn=pm_create_real_vector(mc__bVyeWKHNFpu_5gxm_rTwS,
pm_FbYb_iLqY2hwZTVlVaiqJY);mc__jUbZ5TudDGfVmrpB7MnwY->
mc__HKFYzrt3RxcZqzFAcqapU=pm_create_real_vector(mc__bVyeWKHNFpu_5gxm_rTwS,
pm_FbYb_iLqY2hwZTVlVaiqJY);mc__jUbZ5TudDGfVmrpB7MnwY->
mc_F1q2EnR2giSTdeJuEnNmm3=pm_create_real_vector(mc_Fol7VPru5_d7diNJkJAWvC,
pm_FbYb_iLqY2hwZTVlVaiqJY);mc__jUbZ5TudDGfVmrpB7MnwY->
mc_Fso2jnUIWUtLfuwv9vZA2P=pm_create_real_vector(mc_Vq3VczAgWO8XYqVdDRv4Kb,
pm_FbYb_iLqY2hwZTVlVaiqJY);if(mc__jUbZ5TudDGfVmrpB7MnwY->
mc_VPnByizXfG86dX_49PzmU_.mc__CVAW4jtu3O3Xywuw1sG4q){mc__jUbZ5TudDGfVmrpB7MnwY
->mc_kXZB7gLIpzGRgDLMUplrVP=mc_VOoacG3k_IpceiQb3uHZPf(
mc__67mUhUuDV4sharm2fatDC,mc_FzcJQ1Jxl1hoZDRi6_VHkF,pm_FbYb_iLqY2hwZTVlVaiqJY)
;}else{mc__jUbZ5TudDGfVmrpB7MnwY->mc_kXZB7gLIpzGRgDLMUplrVP=NULL;}(void)0;;
mc__QyEMu_QAQK7YiC6_70ZGE=mc__bVyeWKHNFpu_5gxm_rTwS-mc__RtkHrrPEelBbDRCt5cBnV
->mPrivateData->mc__UQB2tbdDSCFWu8zfrD8xX;mc__1Zf2IciMRCub1vvbEr1C4=
mc_FzcJQ1Jxl1hoZDRi6_VHkF->mCreateLinearAlgebraComplete(
mc_FzcJQ1Jxl1hoZDRi6_VHkF,&(mc__jUbZ5TudDGfVmrpB7MnwY->
mc_F0zpoJfX2j4sj9IETLJq8O),mc__67mUhUuDV4sharm2fatDC,mc__QyEMu_QAQK7YiC6_70ZGE
);(void)0;;mc_V8a_FQ2T6YWLgu_s5UfAPx->mPrivateData=mc__jUbZ5TudDGfVmrpB7MnwY;
mc_V8a_FQ2T6YWLgu_s5UfAPx->mSolve= &mc___FEkSv9KZtwaqN9uPeqOD;
mc_V8a_FQ2T6YWLgu_s5UfAPx->mc__vHH72jqKt44cXWzB3_tSu= &
mc_kPu7ckybzItljXuumjVaxs;mc_V8a_FQ2T6YWLgu_s5UfAPx->mc_FF_Aq2b8Cx_iduzooh_sWO
= &mc__4_Ms9rjBntfaqEEDoFhYk;mc_V8a_FQ2T6YWLgu_s5UfAPx->mDestroy= &
mc_VfIubPxnSq_mXuL8YtnNNe;return mc_V8a_FQ2T6YWLgu_s5UfAPx;}static void
mc_V0B6_uRWCd81a1epbOemmQ(mc_kKrwrwNLgB_NYDY0UUZRVA*mc__RtkHrrPEelBbDRCt5cBnV)
{PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY=mc__RtkHrrPEelBbDRCt5cBnV->mPrivateData
->mc_Ff9S1xA4Ip4ZXeljM4_eEa;{void*mc_kk06poLCQlh5i5Yv6GSh7e=(
mc__RtkHrrPEelBbDRCt5cBnV->mPrivateData);if(mc_kk06poLCQlh5i5Yv6GSh7e!=0){(
pm_FbYb_iLqY2hwZTVlVaiqJY)->mFreeFcn(pm_FbYb_iLqY2hwZTVlVaiqJY,
mc_kk06poLCQlh5i5Yv6GSh7e);}};{void*mc_kk06poLCQlh5i5Yv6GSh7e=(
mc__RtkHrrPEelBbDRCt5cBnV);if(mc_kk06poLCQlh5i5Yv6GSh7e!=0){(
pm_FbYb_iLqY2hwZTVlVaiqJY)->mFreeFcn(pm_FbYb_iLqY2hwZTVlVaiqJY,
mc_kk06poLCQlh5i5Yv6GSh7e);}};}mc_kKrwrwNLgB_NYDY0UUZRVA*
mc__xbUGSPWT3_5jaEUjXpYZ_(PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY,const
McLinearAlgebraFactory*mc_Fiqi8a6cvxOLX1oR_MTbxh,size_t
mc_kF77yGs8Y4pbZunORy8X8l,size_t mc_F_FkJXxKCcG0fTwCI3XAqt,size_t
mc_V0jiAH2gCJ_zYedoHqBU86,size_t mc_VNsIi0F3TL_aeqk8IaSBnl,boolean_T
mc_kw6NOvmP0mtTgTawDfvetp,boolean_T mc_FDZq9eTGbfpXb97L46FmHM,
IterationsLogCore*mc_FBc2dbX9MXKAd5WCw_3i1l){mc_kKrwrwNLgB_NYDY0UUZRVA*
mc__RtkHrrPEelBbDRCt5cBnV=(mc_kKrwrwNLgB_NYDY0UUZRVA*)((
pm_FbYb_iLqY2hwZTVlVaiqJY)->mCallocFcn((pm_FbYb_iLqY2hwZTVlVaiqJY),(sizeof(
mc_kKrwrwNLgB_NYDY0UUZRVA)),(1)));mc_FuB6ZnvWHlGVe5AYB_qh1v*
mc_FJ2Y0frA7_Sle9T2qXzJdY=(mc_FuB6ZnvWHlGVe5AYB_qh1v*)((
pm_FbYb_iLqY2hwZTVlVaiqJY)->mCallocFcn((pm_FbYb_iLqY2hwZTVlVaiqJY),(sizeof(
mc_FuB6ZnvWHlGVe5AYB_qh1v)),(1)));mc_FJ2Y0frA7_Sle9T2qXzJdY->
mc_Ff9S1xA4Ip4ZXeljM4_eEa=pm_FbYb_iLqY2hwZTVlVaiqJY;mc_FJ2Y0frA7_Sle9T2qXzJdY
->mc_FCqUeGcaJ6tVXTKxCgh17W=mc_Fiqi8a6cvxOLX1oR_MTbxh;
mc_FJ2Y0frA7_Sle9T2qXzJdY->mc_k3YP_F9lOAp7Vy_38IwwJz=mc_kF77yGs8Y4pbZunORy8X8l
;mc_FJ2Y0frA7_Sle9T2qXzJdY->mc_F5toqgHxv5CbgmiMEeN1Ri=
mc_F_FkJXxKCcG0fTwCI3XAqt;mc_FJ2Y0frA7_Sle9T2qXzJdY->mc_VK6xPezuw04diXgfU3wa_1
=mc_V0jiAH2gCJ_zYedoHqBU86;mc_FJ2Y0frA7_Sle9T2qXzJdY->
mc__UQB2tbdDSCFWu8zfrD8xX=mc_VNsIi0F3TL_aeqk8IaSBnl;mc_FJ2Y0frA7_Sle9T2qXzJdY
->mc__NTUGzBJhMGgfiDsBm1dv3=mc_kw6NOvmP0mtTgTawDfvetp;
mc_FJ2Y0frA7_Sle9T2qXzJdY->mc__CVAW4jtu3O3Xywuw1sG4q=mc_FDZq9eTGbfpXb97L46FmHM
;mc_FJ2Y0frA7_Sle9T2qXzJdY->mc_kV0hFh2l2Wx4dit9DlxIa_=
mc_FBc2dbX9MXKAd5WCw_3i1l;mc__RtkHrrPEelBbDRCt5cBnV->mPrivateData=
mc_FJ2Y0frA7_Sle9T2qXzJdY;mc__RtkHrrPEelBbDRCt5cBnV->mc_k_hVWBJWCUlCdPNZka5iZF
= &mc__tPeUeveyLKtbPsJ38Xq7C;mc__RtkHrrPEelBbDRCt5cBnV->mDestroy= &
mc_V0B6_uRWCd81a1epbOemmQ;return mc__RtkHrrPEelBbDRCt5cBnV;}
