#include "pm_std.h"
struct sm__OPMIvyoNy0NVqnW_nU68y{unsigned int sm_VEaVFomK_ZSqbm85CCLWGg;};
typedef struct sm__OPMIvyoNy0NVqnW_nU68y sm_FfWn1_qsdRG7aDJTN7g4uK;void
sm_F3PGNOiDqi_NfHlAwMLmW5(sm_FfWn1_qsdRG7aDJTN7g4uK*sm_F4y5iyDnuuG0j1Z6aPqvG2,
unsigned int sm_k6QxQSbjWyGhcXikh7jTLf);unsigned int sm_FsYXHAB_HJWKiPtzFJqV3l
(sm_FfWn1_qsdRG7aDJTN7g4uK*sm_F4y5iyDnuuG0j1Z6aPqvG2,unsigned int
pm_kpzAtHMD4_WnheH0UiioSE);boolean_T sm_VNeikr0KcPdLbi5vXDc5jX(
sm_FfWn1_qsdRG7aDJTN7g4uK*sm_F4y5iyDnuuG0j1Z6aPqvG2);unsigned int
sm_Vof_mw_Nt0dLaiXlCWpfdk(sm_FfWn1_qsdRG7aDJTN7g4uK*sm_F4y5iyDnuuG0j1Z6aPqvG2,
size_t n);int sm_FqJkrj441j8JVP_ZqQB2Tx(sm_FfWn1_qsdRG7aDJTN7g4uK*
sm_F4y5iyDnuuG0j1Z6aPqvG2,int sm_FgkSoAqE75lsVqCT0s070P,int
sm_kH3bO_YJW98YWa3J39Vj1I);double sm_VFBt4NZxAf_4V1NpMmKcwP(
sm_FfWn1_qsdRG7aDJTN7g4uK*sm_F4y5iyDnuuG0j1Z6aPqvG2,double
sm_kH3bO_YJW98YWa3J39Vj1I);double sm_VwtOv9wGNz8Pfij8a9yfpy(
sm_FfWn1_qsdRG7aDJTN7g4uK*sm_F4y5iyDnuuG0j1Z6aPqvG2,double
sm__zdo1IIzcfhsXq3q6OLUsg);
#include "pm_std.h"
static void sm_FQMT2akqYvxBYX8X3tE6cZ(sm_FfWn1_qsdRG7aDJTN7g4uK*
sm_F4y5iyDnuuG0j1Z6aPqvG2){const unsigned int a=0x4A71FE3D;const unsigned int
sm_FFZbGh27ya8eem_J_hUtAZ=263941511;sm_F4y5iyDnuuG0j1Z6aPqvG2->
sm_VEaVFomK_ZSqbm85CCLWGg*=a;sm_F4y5iyDnuuG0j1Z6aPqvG2->
sm_VEaVFomK_ZSqbm85CCLWGg+=sm_FFZbGh27ya8eem_J_hUtAZ;}void
sm_F3PGNOiDqi_NfHlAwMLmW5(sm_FfWn1_qsdRG7aDJTN7g4uK*sm_F4y5iyDnuuG0j1Z6aPqvG2,
unsigned int sm_k6QxQSbjWyGhcXikh7jTLf){sm_F4y5iyDnuuG0j1Z6aPqvG2->
sm_VEaVFomK_ZSqbm85CCLWGg=sm_k6QxQSbjWyGhcXikh7jTLf;}unsigned int
sm_FsYXHAB_HJWKiPtzFJqV3l(sm_FfWn1_qsdRG7aDJTN7g4uK*sm_F4y5iyDnuuG0j1Z6aPqvG2,
unsigned int pm_kpzAtHMD4_WnheH0UiioSE){unsigned int orig=
sm_F4y5iyDnuuG0j1Z6aPqvG2->sm_VEaVFomK_ZSqbm85CCLWGg;sm_F4y5iyDnuuG0j1Z6aPqvG2
->sm_VEaVFomK_ZSqbm85CCLWGg=pm_kpzAtHMD4_WnheH0UiioSE;return orig;}boolean_T
sm_VNeikr0KcPdLbi5vXDc5jX(sm_FfWn1_qsdRG7aDJTN7g4uK*sm_F4y5iyDnuuG0j1Z6aPqvG2)
{sm_FQMT2akqYvxBYX8X3tE6cZ(sm_F4y5iyDnuuG0j1Z6aPqvG2);return((int)
sm_F4y5iyDnuuG0j1Z6aPqvG2->sm_VEaVFomK_ZSqbm85CCLWGg)<0;}unsigned int
sm_Vof_mw_Nt0dLaiXlCWpfdk(sm_FfWn1_qsdRG7aDJTN7g4uK*sm_F4y5iyDnuuG0j1Z6aPqvG2,
size_t sm_VIcG_VfzM3GqVuXRxblhzq){const unsigned int n=(unsigned int)
sm_VIcG_VfzM3GqVuXRxblhzq;int b;unsigned int sm_kwrB3ZoKf7OufTHWaHJV7a,
sm_VU18hM_2GHSHWue20_mnXQ,sm_FaTMtbGpag0qaDjs4pd17i;sm_FQMT2akqYvxBYX8X3tE6cZ(
sm_F4y5iyDnuuG0j1Z6aPqvG2);if(n==0)return sm_F4y5iyDnuuG0j1Z6aPqvG2->
sm_VEaVFomK_ZSqbm85CCLWGg;b=0;for(sm_kwrB3ZoKf7OufTHWaHJV7a=n;
sm_kwrB3ZoKf7OufTHWaHJV7a!=0;sm_kwrB3ZoKf7OufTHWaHJV7a>>=1,++b){}
sm_VU18hM_2GHSHWue20_mnXQ=(b==32)?0xFFFFFFFF:((1u<<b)-1);
sm_FaTMtbGpag0qaDjs4pd17i=(sm_F4y5iyDnuuG0j1Z6aPqvG2->
sm_VEaVFomK_ZSqbm85CCLWGg>>(32-b))&sm_VU18hM_2GHSHWue20_mnXQ;while(
sm_FaTMtbGpag0qaDjs4pd17i>=n){sm_FQMT2akqYvxBYX8X3tE6cZ(
sm_F4y5iyDnuuG0j1Z6aPqvG2);sm_FaTMtbGpag0qaDjs4pd17i=(
sm_F4y5iyDnuuG0j1Z6aPqvG2->sm_VEaVFomK_ZSqbm85CCLWGg>>(32-b))&
sm_VU18hM_2GHSHWue20_mnXQ;}return sm_FaTMtbGpag0qaDjs4pd17i;}int
sm_FqJkrj441j8JVP_ZqQB2Tx(sm_FfWn1_qsdRG7aDJTN7g4uK*sm_F4y5iyDnuuG0j1Z6aPqvG2,
int sm_FgkSoAqE75lsVqCT0s070P,int sm_kH3bO_YJW98YWa3J39Vj1I){(void)0;;return
sm_FgkSoAqE75lsVqCT0s070P+(int)sm_Vof_mw_Nt0dLaiXlCWpfdk(
sm_F4y5iyDnuuG0j1Z6aPqvG2,(size_t)(sm_kH3bO_YJW98YWa3J39Vj1I-
sm_FgkSoAqE75lsVqCT0s070P+1));}double sm_VFBt4NZxAf_4V1NpMmKcwP(
sm_FfWn1_qsdRG7aDJTN7g4uK*sm_F4y5iyDnuuG0j1Z6aPqvG2,double
sm_kH3bO_YJW98YWa3J39Vj1I){(void)0;;return sm_kH3bO_YJW98YWa3J39Vj1I*(
sm_Vof_mw_Nt0dLaiXlCWpfdk(sm_F4y5iyDnuuG0j1Z6aPqvG2,0)/4294967296.0);}double
sm_VwtOv9wGNz8Pfij8a9yfpy(sm_FfWn1_qsdRG7aDJTN7g4uK*sm_F4y5iyDnuuG0j1Z6aPqvG2,
double sm__zdo1IIzcfhsXq3q6OLUsg){return sm_VFBt4NZxAf_4V1NpMmKcwP(
sm_F4y5iyDnuuG0j1Z6aPqvG2,2.0*sm__zdo1IIzcfhsXq3q6OLUsg)-
sm__zdo1IIzcfhsXq3q6OLUsg;}
