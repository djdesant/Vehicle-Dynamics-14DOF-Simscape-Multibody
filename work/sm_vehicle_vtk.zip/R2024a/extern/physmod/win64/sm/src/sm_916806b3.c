#include "pm_std.h"
#include "math.h"
struct sm_FsrmfFRSbBOkg5DK_JDtbp{real_T sm_VnIU3pm_im4PdeIcvHeFon;real_T
sm__N_In_d5DhGVVH9s0RNZ_r;};typedef struct sm_FsrmfFRSbBOkg5DK_JDtbp
sm_k5_AjprLH5doVmvV8WHqqA;sm_k5_AjprLH5doVmvV8WHqqA sm_kR28cHyta4GEj5Gl3Asra9(
real_T(*sm__I45QXDj9vhGZeg1ViY2wU)(real_T),real_T sm_FgkSoAqE75lsVqCT0s070P,
real_T sm_kH3bO_YJW98YWa3J39Vj1I);sm_k5_AjprLH5doVmvV8WHqqA
sm_FHO6HCOj8M_biqJ5BdW_av(real_T(*sm__I45QXDj9vhGZeg1ViY2wU)(real_T),real_T
sm_FgkSoAqE75lsVqCT0s070P,real_T sm_kH3bO_YJW98YWa3J39Vj1I){const real_T
sm_FxVx8bRexTl3hDBcGo5O3w=1e-10;int32_T sm_F2OC7L115klBYmszczVm5A=100;const
real_T sm_F1bBEEncY_WseqbBpdqHA1=0.3819660;int32_T sm__BwCbGCDlrx2gDK5rof3H8=0
;sm_k5_AjprLH5doVmvV8WHqqA sm_kH7c9UGCUNOFXqT6Omambe;real_T x;real_T
sm_V1pxxydYEnWVVi3QKesjvf;real_T sm_VgJW5ZqpwPpuY1inYtaofQ;real_T
sm_kEbBObcYFIxUZ5_77V3CO_;real_T sm_kDTYNj3erXleeDgn6ZWFBW;real_T
sm_F89D5_xDWdlRi9PuTagrCV;real_T sm__T2VhfxT2Jh_WHX980uWNe,
sm__Pv2XTxMXp0CfD8YoxJoJ_,sm_FAHvX__zwg_Y_Xr16_B6o2,sm_VfYdO49WvvSgY1PGUDdDsc;
real_T sm_kkX5Np8moDtzfD62egX1Ls;real_T sm_Vd0qw_aY3H_ibegEL7brEv,
sm__CUfNKxvmE8scyzoO_Ck4V;real_T pm__lqjegyKuwStj56WZLiC_e=0,
sm__AExROh1PVWNeP7hmMWuJv=0,sm_kUQBO1dSP8_IVqRAUx4R8G=0;real_T
sm_k1ly0IlEvClo_DLd9a1KJn=0;x=sm_V1pxxydYEnWVVi3QKesjvf=
sm_VgJW5ZqpwPpuY1inYtaofQ=sm_kH3bO_YJW98YWa3J39Vj1I;sm_FAHvX__zwg_Y_Xr16_B6o2=
sm__Pv2XTxMXp0CfD8YoxJoJ_=sm_VfYdO49WvvSgY1PGUDdDsc=sm__I45QXDj9vhGZeg1ViY2wU(
x);sm_F89D5_xDWdlRi9PuTagrCV=sm_kDTYNj3erXleeDgn6ZWFBW=0;
sm__BwCbGCDlrx2gDK5rof3H8=sm_F2OC7L115klBYmszczVm5A;do{
sm_kkX5Np8moDtzfD62egX1Ls=(sm_FgkSoAqE75lsVqCT0s070P+sm_kH3bO_YJW98YWa3J39Vj1I
)/2;sm_Vd0qw_aY3H_ibegEL7brEv=sm_FxVx8bRexTl3hDBcGo5O3w*fabs(x)+
sm_FxVx8bRexTl3hDBcGo5O3w/4;sm__CUfNKxvmE8scyzoO_Ck4V=2*
sm_Vd0qw_aY3H_ibegEL7brEv;if(fabs(x-sm_kkX5Np8moDtzfD62egX1Ls)<=(
sm__CUfNKxvmE8scyzoO_Ck4V-(sm_kH3bO_YJW98YWa3J39Vj1I-sm_FgkSoAqE75lsVqCT0s070P
)/2)){break;}if(fabs(sm_F89D5_xDWdlRi9PuTagrCV)>sm_Vd0qw_aY3H_ibegEL7brEv){
sm_kUQBO1dSP8_IVqRAUx4R8G=(x-sm_V1pxxydYEnWVVi3QKesjvf)*(
sm_VfYdO49WvvSgY1PGUDdDsc-sm__Pv2XTxMXp0CfD8YoxJoJ_);sm__AExROh1PVWNeP7hmMWuJv
=(x-sm_VgJW5ZqpwPpuY1inYtaofQ)*(sm_VfYdO49WvvSgY1PGUDdDsc-
sm_FAHvX__zwg_Y_Xr16_B6o2);pm__lqjegyKuwStj56WZLiC_e=(x-
sm_VgJW5ZqpwPpuY1inYtaofQ)*sm__AExROh1PVWNeP7hmMWuJv-(x-
sm_V1pxxydYEnWVVi3QKesjvf)*sm_kUQBO1dSP8_IVqRAUx4R8G;sm__AExROh1PVWNeP7hmMWuJv
=2*(sm__AExROh1PVWNeP7hmMWuJv-sm_kUQBO1dSP8_IVqRAUx4R8G);if(
sm__AExROh1PVWNeP7hmMWuJv>0){pm__lqjegyKuwStj56WZLiC_e= -
pm__lqjegyKuwStj56WZLiC_e;}sm__AExROh1PVWNeP7hmMWuJv=fabs(
sm__AExROh1PVWNeP7hmMWuJv);sm_k1ly0IlEvClo_DLd9a1KJn=sm_F89D5_xDWdlRi9PuTagrCV
;sm_F89D5_xDWdlRi9PuTagrCV=sm_kDTYNj3erXleeDgn6ZWFBW;if((fabs(
pm__lqjegyKuwStj56WZLiC_e)>=fabs(sm__AExROh1PVWNeP7hmMWuJv*
sm_k1ly0IlEvClo_DLd9a1KJn/2))||(pm__lqjegyKuwStj56WZLiC_e<=
sm__AExROh1PVWNeP7hmMWuJv*(sm_FgkSoAqE75lsVqCT0s070P-x))||(
pm__lqjegyKuwStj56WZLiC_e>=sm__AExROh1PVWNeP7hmMWuJv*(
sm_kH3bO_YJW98YWa3J39Vj1I-x))){sm_F89D5_xDWdlRi9PuTagrCV=(x>=
sm_kkX5Np8moDtzfD62egX1Ls)?sm_FgkSoAqE75lsVqCT0s070P-x:
sm_kH3bO_YJW98YWa3J39Vj1I-x;sm_kDTYNj3erXleeDgn6ZWFBW=
sm_F1bBEEncY_WseqbBpdqHA1*sm_F89D5_xDWdlRi9PuTagrCV;}else{
sm_kDTYNj3erXleeDgn6ZWFBW=pm__lqjegyKuwStj56WZLiC_e/sm__AExROh1PVWNeP7hmMWuJv;
sm_kEbBObcYFIxUZ5_77V3CO_=x+sm_kDTYNj3erXleeDgn6ZWFBW;if(((
sm_kEbBObcYFIxUZ5_77V3CO_-sm_FgkSoAqE75lsVqCT0s070P)<sm__CUfNKxvmE8scyzoO_Ck4V
)||((sm_kH3bO_YJW98YWa3J39Vj1I-sm_kEbBObcYFIxUZ5_77V3CO_)<
sm__CUfNKxvmE8scyzoO_Ck4V)){sm_kDTYNj3erXleeDgn6ZWFBW=(
sm_kkX5Np8moDtzfD62egX1Ls-x)<0?-fabs(sm_Vd0qw_aY3H_ibegEL7brEv):fabs(
sm_Vd0qw_aY3H_ibegEL7brEv);}}}else{sm_F89D5_xDWdlRi9PuTagrCV=(x>=
sm_kkX5Np8moDtzfD62egX1Ls)?sm_FgkSoAqE75lsVqCT0s070P-x:
sm_kH3bO_YJW98YWa3J39Vj1I-x;sm_kDTYNj3erXleeDgn6ZWFBW=
sm_F1bBEEncY_WseqbBpdqHA1*sm_F89D5_xDWdlRi9PuTagrCV;}sm_kEbBObcYFIxUZ5_77V3CO_
=(fabs(sm_kDTYNj3erXleeDgn6ZWFBW)>=sm_Vd0qw_aY3H_ibegEL7brEv)?(x+
sm_kDTYNj3erXleeDgn6ZWFBW):(sm_kDTYNj3erXleeDgn6ZWFBW>0?(x+fabs(
sm_Vd0qw_aY3H_ibegEL7brEv)):(x-fabs(sm_Vd0qw_aY3H_ibegEL7brEv)));
sm__T2VhfxT2Jh_WHX980uWNe=sm__I45QXDj9vhGZeg1ViY2wU(sm_kEbBObcYFIxUZ5_77V3CO_)
;if(sm__T2VhfxT2Jh_WHX980uWNe<=sm_VfYdO49WvvSgY1PGUDdDsc){if(
sm_kEbBObcYFIxUZ5_77V3CO_>=x){sm_FgkSoAqE75lsVqCT0s070P=x;}else{
sm_kH3bO_YJW98YWa3J39Vj1I=x;}sm_VgJW5ZqpwPpuY1inYtaofQ=
sm_V1pxxydYEnWVVi3QKesjvf;sm_V1pxxydYEnWVVi3QKesjvf=x;x=
sm_kEbBObcYFIxUZ5_77V3CO_;sm__Pv2XTxMXp0CfD8YoxJoJ_=sm_FAHvX__zwg_Y_Xr16_B6o2;
sm_FAHvX__zwg_Y_Xr16_B6o2=sm_VfYdO49WvvSgY1PGUDdDsc;sm_VfYdO49WvvSgY1PGUDdDsc=
sm__T2VhfxT2Jh_WHX980uWNe;}else{if(sm_kEbBObcYFIxUZ5_77V3CO_<x){
sm_FgkSoAqE75lsVqCT0s070P=sm_kEbBObcYFIxUZ5_77V3CO_;}else{
sm_kH3bO_YJW98YWa3J39Vj1I=sm_kEbBObcYFIxUZ5_77V3CO_;}if((
sm__T2VhfxT2Jh_WHX980uWNe<=sm_FAHvX__zwg_Y_Xr16_B6o2)||(
sm_V1pxxydYEnWVVi3QKesjvf==x)){sm_VgJW5ZqpwPpuY1inYtaofQ=
sm_V1pxxydYEnWVVi3QKesjvf;sm_V1pxxydYEnWVVi3QKesjvf=sm_kEbBObcYFIxUZ5_77V3CO_;
sm__Pv2XTxMXp0CfD8YoxJoJ_=sm_FAHvX__zwg_Y_Xr16_B6o2;sm_FAHvX__zwg_Y_Xr16_B6o2=
sm__T2VhfxT2Jh_WHX980uWNe;}else if((sm__T2VhfxT2Jh_WHX980uWNe<=
sm__Pv2XTxMXp0CfD8YoxJoJ_)||(sm_VgJW5ZqpwPpuY1inYtaofQ==x)||(
sm_VgJW5ZqpwPpuY1inYtaofQ==sm_V1pxxydYEnWVVi3QKesjvf)){
sm_VgJW5ZqpwPpuY1inYtaofQ=sm_kEbBObcYFIxUZ5_77V3CO_;sm__Pv2XTxMXp0CfD8YoxJoJ_=
sm__T2VhfxT2Jh_WHX980uWNe;}}}while(--sm__BwCbGCDlrx2gDK5rof3H8);
sm_F2OC7L115klBYmszczVm5A-=sm__BwCbGCDlrx2gDK5rof3H8;sm_kH7c9UGCUNOFXqT6Omambe
.sm_VnIU3pm_im4PdeIcvHeFon=x;sm_kH7c9UGCUNOFXqT6Omambe.
sm__N_In_d5DhGVVH9s0RNZ_r=sm_VfYdO49WvvSgY1PGUDdDsc;return
sm_kH7c9UGCUNOFXqT6Omambe;}sm_k5_AjprLH5doVmvV8WHqqA sm_kR28cHyta4GEj5Gl3Asra9
(real_T(*sm__I45QXDj9vhGZeg1ViY2wU)(real_T),real_T sm_FgkSoAqE75lsVqCT0s070P,
real_T sm_kH3bO_YJW98YWa3J39Vj1I){return sm_FHO6HCOj8M_biqJ5BdW_av(
sm__I45QXDj9vhGZeg1ViY2wU,sm_FgkSoAqE75lsVqCT0s070P,sm_kH3bO_YJW98YWa3J39Vj1I)
;}
