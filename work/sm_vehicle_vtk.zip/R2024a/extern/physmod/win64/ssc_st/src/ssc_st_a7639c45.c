struct ssc_st_kesYKdRukKtCYLfoQ0YRJ5{struct{char const*
ssc_st_VVZIuzCXXbhFgXdcjs2BgI;char const*ssc_st__gTAJhmd_b0PZPv7REnF88;char
const*ssc_st_VoyCaSFC6CGLc5Rsd2Zqcv;char const*ssc_st__39hATFoDY8W_Lgr8uBPKF;
char const*ssc_st_kRCXBRXAKY0t_eKj9bUPER;char const*
ssc_st_VaQIb0KMootZbuEvSD_xtw;char const*ssc_st_k3U67pGpbKl0duWo3_ku41;char
const*ssc_st_kZF6UK63wc80dLibPvFzZ5;}ssc_st_FPtMF2fRCsh_fTxnenNYzX;struct{char
const*ssc_st_V_I9ZlTcE4CZb1Tw7wtZGX;char const*ssc_st__qMaoP8OVEGrgmx3ZP0Mj9;
char const*ssc_st_kMDLd9TMEWpxa14nB7xyQz;}ssc_st_FIBEYF8fIO4o_isvvmL_1_;struct
{char const*A;char const*mc_Vqiy96WqvuhCaXm5e_vvT0;char const*
ssc_st_FStFcQlyAJ_dVy4kGZXBPQ;char const*ssc_st_kyfq6L_eQbdYcPuOovpRDW;char
const*ssc_st_V8XMtcd13M8FjLV0KvZZWM;}ssc_st__l_QKzst7mxEcqpORUCYnt;};extern
struct ssc_st_kesYKdRukKtCYLfoQ0YRJ5 ssc_st_kykE87VnIQ00YXfz_8Mno_;struct
ssc_st_kesYKdRukKtCYLfoQ0YRJ5 ssc_st_kykE87VnIQ00YXfz_8Mno_={{"%s %s",
"At time %s, one or more assertions are triggered.",
"%s See causes for specific information.",
"%s The assertion comes from:\nBlock path: %s\nAssert location: %s\n",
"The assertion comes from:\nBlock path: %s\nAssert location: %s\n",
"In between line: %s, column: %s and line: %s, column: %s in file: %s",
"(location information is protected)",
"At parameter initialization, one or more assertions are triggered.",},{
"... (Truncated error message at maximum length of buffer.)\n",
"Unexpected internal error: diagnostic error message requested but tree is empty."
,"%s",},{"Alice","Bob","Chris eats %s","Dan","Ernie",},};
