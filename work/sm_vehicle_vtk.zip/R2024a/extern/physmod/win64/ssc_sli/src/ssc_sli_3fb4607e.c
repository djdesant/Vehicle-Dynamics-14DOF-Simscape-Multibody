#include "pm_std.h"
typedef struct ssc_sli_FVf_amd3AH8LfenwIlqHva ssc_sli_VVLRXiA4WGpZVaIFYAN8PM;
typedef struct ssc_sli__kS2YfwGyKC6bHrot_r1HQ ssc_sli_VryjWf9wHphDeeRWoDuv4k;
struct ssc_sli_FVf_amd3AH8LfenwIlqHva{void(*ssc_sli_VF5T7_4o_U8sh9eS4_Ee3s)(
ssc_sli_VVLRXiA4WGpZVaIFYAN8PM*);void(*ssc_sli_FkOnu54reaGRbeQmmTIPpX)(
ssc_sli_VVLRXiA4WGpZVaIFYAN8PM*,double ssc_sli_VvRqQ1t0d9_vX9zcRjefhP,double
const*ssc_sli__EvZPycF9p4_YTSoYvLvQN,double*buffer);void(*
ssc_sli_Vi_8vOV9RH_Of91AvTG8Aa)(ssc_sli_VVLRXiA4WGpZVaIFYAN8PM*);
ssc_sli_VryjWf9wHphDeeRWoDuv4k*ssc_sli__nuQtF0ZiztwhuJ2yPfZyu;};
#include "pm_std.h"
#include "pm_std.h"
#include "ne_std_fwd.h"
#include "pm_std.h"
#include "stdarg.h"
typedef NeuDiagnosticTree*ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E;typedef struct
ssc_st__0atO_17n_Ci_qYhoCxFUV ssc_st_F04yXT_zz14zgHdLildPgK;struct
NeuDiagnosticManagerTag{ssc_st_F04yXT_zz14zgHdLildPgK*mPrivateData;
ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E(*ssc_st_VESUSzIzeRWSV1xYVr5zH5)(const
NeuDiagnosticManager*ssc_st_kPInN_8SRA_iYeTvYVKl3z);void(*
ssc_st__RtuwtEn2c_yh1OySiqODN)(const NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z,ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E
ssc_st_k3bA0_SocS_baqMdimEffE,NeuDiagnosticLevel ssc_st_FlRsyRMpiRpNY9kP14dKKM
,PmfMessageId ssc_st__C0ajRzPQzOpeHB7hy4YXo,va_list args);void(*
ssc_st__YxE_N42_idoWyreGeTz9t)(const NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z,ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E
ssc_st_k3bA0_SocS_baqMdimEffE,NeuDiagnosticLevel ssc_st_FlRsyRMpiRpNY9kP14dKKM
,PmfMessageId ssc_st__C0ajRzPQzOpeHB7hy4YXo,va_list args);void(*
ssc_st_kAPwXpB5miCGVLsko_7ONE)(const NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z,ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E
ssc_st_k3bA0_SocS_baqMdimEffE);void(*ssc_st__u9riBfE3RK3ZXQpAXjZW_)(const
NeuDiagnosticManager*ssc_st_FgQH451kC4lOZ5A2coatZe,const NeuDiagnosticManager*
src);const NeuDiagnosticTree*(*ssc_st_kqsZroyTBbpjb1za_BT1dv)(const
NeuDiagnosticManager*ssc_st_kPInN_8SRA_iYeTvYVKl3z);void(*mDestroy)(
NeuDiagnosticManager*ssc_st_kPInN_8SRA_iYeTvYVKl3z);};PmfMessageId
ssc_st_Fj4pG1CbqChThqCdYV3xux(const NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z,ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E
ssc_st_k3bA0_SocS_baqMdimEffE,NeuDiagnosticLevel ssc_st_FlRsyRMpiRpNY9kP14dKKM
,PmfMessageId ssc_st__C0ajRzPQzOpeHB7hy4YXo,...);PmfMessageId
ssc_st_FqMmOIGGjkpTZ58Esd_XuA(const NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z,ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E
ssc_st_k3bA0_SocS_baqMdimEffE,NeuDiagnosticLevel ssc_st_FlRsyRMpiRpNY9kP14dKKM
,PmfMessageId ssc_st__C0ajRzPQzOpeHB7hy4YXo,...);PmfMessageId
ssc_st_F5XP0Is_HAWucugpsjE8XK(const NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z,NeuDiagnosticLevel ssc_st_FlRsyRMpiRpNY9kP14dKKM
,PmfMessageId ssc_st__C0ajRzPQzOpeHB7hy4YXo,...);PmfMessageId
ssc_st__w8As0Yf6B8Ji9iMi5WOGi(const NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z,ssc_st_FjUEd5ZQJA0Ej1IosTlZ5E
ssc_st_k3bA0_SocS_baqMdimEffE,NeuDiagnosticLevel ssc_st_FlRsyRMpiRpNY9kP14dKKM
,PmfMessageId ssc_st__C0ajRzPQzOpeHB7hy4YXo,const char*
ssc_st_kvsOBKjJwlx5dTxrw7qAwS);PmfMessageId ssc_st__xrkslL_b0pOemBxsxBQx0(
const NeuDiagnosticManager*ssc_st_kPInN_8SRA_iYeTvYVKl3z,NeuDiagnosticLevel
ssc_st_FlRsyRMpiRpNY9kP14dKKM,PmfMessageId ssc_st__C0ajRzPQzOpeHB7hy4YXo,const
char*ssc_st_kvsOBKjJwlx5dTxrw7qAwS);NeuDiagnosticManager*
neu_create_diagnostic_manager(PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z);void
neu_destroy_diagnostic_manager(NeuDiagnosticManager*
ssc_st_kPInN_8SRA_iYeTvYVKl3z);
#include "ne_std.h"
struct ssc_sli_F6qMnmarpj0_bL95mS6_OX{PmSparsityPattern
ssc_sli_Vx2DkH_aGwC6aD1vs_p7b5;PmRealVector ssc_sli__X0aAlJnshW5a5o4_p4iqY;
PmSparsityPattern ssc_sli_Vd_K4At54IxecuOLwYFqBS;PmRealVector
ssc_sli_kMWILSrh3_4vaLiThqAZTo;PmRealVector ssc_sli_FxAWURAOat0g_9RImPYOww;};
typedef struct ssc_sli_F6qMnmarpj0_bL95mS6_OX ssc_sli_Vplml4ZkoXdXiPJ0_n_3bN;
struct ssc_sli_VQM_iwjfsG4BhXrtRasJxo{ssc_sli_Vplml4ZkoXdXiPJ0_n_3bN
ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn;};typedef struct ssc_sli_VQM_iwjfsG4BhXrtRasJxo
ssc_sli_VMjb5gEwDk_XYTR_Pn6Gw3;void ssc_sli_VUJoYf7OYcxCe1PJqvn5lf(const
ssc_sli_VMjb5gEwDk_XYTR_Pn6Gw3*ssc_sli__4XvhALQR2lPZ9Y_4fOD7S,const
NeDynamicSystemInput*mc_kDRphcAfRHSbf1ZLKEDW9k,PmRealVector*
mc_VgqbsB_3R4GTjLQeEYi1Qc,NeuDiagnosticManager*ssc_st_kPInN_8SRA_iYeTvYVKl3z);
ssc_sli_VVLRXiA4WGpZVaIFYAN8PM*ssc_lti_create_rtw_log_fcn_manager(const
ssc_sli_VMjb5gEwDk_XYTR_Pn6Gw3*ssc_sli_FYzfxIMyuJ0Miil_d9sZRR,real_T
ssc_core_VLqJ3svt4etifXi9ymcxVh,unsigned int ssc_sli__FzHy7eP4U8mYieLA8vxNL,
unsigned int ssc_core_kWAFYs9e5LChXqH2wQXohB,unsigned int
ssc_sli_FvABE_TRVHxHfyWgjkDczK,unsigned int ssc_sli_VCo8SY6nzo_VgHvcPodhHy,
NeuDiagnosticManager*ssc_sli_VSMZoNPtzlGdfyr7dHkXMr);
#include "string.h"
#include "pm_std.h"
PmAllocator*pm_default_allocator(void);
#include "pm_std.h"
int_T pm_kkW9oQAVI7Wt_9Rzuat5bx(PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
size_t pm_keOJjiAyBTtFhyWf033kni,size_t pm_kJxontPsxndNYXwDXdE1iy,size_t
pm_kPvICtSd_wWNieTWLEBFD1,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);
PmSparsityPattern*pm_create_sparsity_pattern(size_t pm_keOJjiAyBTtFhyWf033kni,
size_t pm_kJxontPsxndNYXwDXdE1iy,size_t pm_kPvICtSd_wWNieTWLEBFD1,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kTFq3qlgTulWiT6pafkmmT(PmSparsityPattern*
pm__56dBn4vKXWjZ1nclFRYZB,const PmSparsityPattern*pm_kAWy4EaHbpxVbT_qyApDbv);
boolean_T pm__ZRI70SuGwhmamUtcsoyxS(const PmSparsityPattern*
pm__56dBn4vKXWjZ1nclFRYZB,const PmSparsityPattern*pm_kAWy4EaHbpxVbT_qyApDbv);
PmSparsityPattern*pm_FQMLyYzCQ5CtgHjze1nNJP(const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FvcKvutPfxG9Xe1kjs7gg0(PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);void pm_VYooJBURCwKrVu6RXzQZ_5(
PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*pm__YwdRBXissh3bPWPl30Fpe(size_t
pm_FW8nEXbTFjdJhTIKepsgFT,size_t pm_FsQ9LRKHRTKdgeP2xWDL07,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*pm_FFniD_kRQg_JWTYc5cmjGs(size_t
pm_FW8nEXbTFjdJhTIKepsgFT,size_t pm_FsQ9LRKHRTKdgeP2xWDL07,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*pm_FhqtSrxlPotrcypQHJ9Dcq(size_t
pm__lqjegyKuwStj56WZLiC_e,size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*pm__TNI3M36rThlaTetY4tWiB(size_t n,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);
#include "pm_std.h"
void pm_rv_equals_rv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void pm_VeeoZXnlJQ4u_112lGs8YD(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void pm_kpDvbw1GUlp4c5YdnW7V_w(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
pm_V2SLaBJy5WtXim9Lma9hfD(const PmCharVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmCharVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_FltUsml2sTlHZuCkbw_pdM(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_V8yYQkcd0vp_YaLM_nd75E(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm__P4MWKrtjzGPcercL4W7Fn(const
PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF);int_T pm_create_real_vector_fields(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmRealVector*pm_create_real_vector(size_t numElements,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmRealVector*pm_V_q_QnwoVVl6fHS_0pLvYo(const
PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_VeffaD_A8DxagH31Usec1H(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_destroy_real_vector(
PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
int_T pm_create_int_vector_fields(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t
size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmIntVector*pm_create_int_vector(
size_t numElements,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmIntVector*
pm__fSS_VMqhWlobeqe6mQF_x(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_V_eFnKjg5I4Uc1DwG4yU27(
PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_destroy_int_vector(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_bool_vector_fields(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmBoolVector*pm__jbisDMumXdocXANx5LhhY(size_t numElements,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kia_QXK77_xDg9M1NzHr3r(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_VuaGyqV_9K0Ia9Qgn65rsj(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmBoolVector*pm_kpRdzyG9L_8MV5lRovACCg(const
PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
int_T pm_create_char_vector_fields(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,
size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmCharVector*
pm_VUwRqkQ4oj4FjX20jJYKVB(size_t numElements,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_destroy_char_vector_fields(PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_Vb1pkQZ6CdGmbmIAJ3mnfZ(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_size_vector_fields(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSizeVector*pm_FZch3YyGWrOM_PQNdo7b2c(size_t numElements,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_FlA06lYLRAWkWmGBVmxE1a(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_kWBi8ZqmeopPhmEU9I2aNH(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_FJsPJplguVOI_1EYyUUvfK(const PmSizeVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);
boolean_T pm_kJR6lA3GKXdrdqFEbgLIwb(const PmSizeVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);
#include "pm_std.h"
#include "pm_std.h"
#include "mc_std_fwd.h"
typedef enum{mc_FfS9gFGHqKt_fDwFfcldkw= -1,mc_FFaaXY_gkbSTcyLBvtfrzS,
mc_VUd8H_Dz0yp8cmQqTd7DxF,mc_kmVKy2ciwP4fcTEzXFmnvU,mc_VW_0L0rb93GgXq8_OmdwHv,
mc_kHoWGgwi3OdzaXvPvG1YY7,mc___D_4trEmdK8jyKCH6E_ac,mc_Fei8BCRUgBdwhDvvD5FrSo}
mc_kQtOKCqS08dIbumyDnHNDL;typedef struct mc_VJ95jMweiZWSVLsSPpLjbI
mc__w8slDeOjOCYX5XtAOAaVQ;struct McRealFunctionTag{mc__w8slDeOjOCYX5XtAOAaVQ*
mc_ko6_hiERTRldgDROOJBQCH;mc_kQtOKCqS08dIbumyDnHNDL(*mc_VAvAkWmhpT_WWme_3E1U91
)(const void*mc_kDRphcAfRHSbf1ZLKEDW9k,const PmRealVector*
mc_VgqbsB_3R4GTjLQeEYi1Qc,mc__w8slDeOjOCYX5XtAOAaVQ*mc__d1alWYexptL_X5HTFhbNK)
;const void*(*mc_FXz9GdGvpOKnh5e2dYstBe)(const McRealFunction*
mc_k0CXwzVaibdnZiGUCx6PMZ);void(*mDestroy)(McRealFunction*
mc_k0CXwzVaibdnZiGUCx6PMZ);};typedef struct mc_VqsYk672m3G9YuweR9VjuM
mc_Vfjzfv7SnSWthXl7BAncu7;struct McIntFunctionTag{mc_Vfjzfv7SnSWthXl7BAncu7*
mc_ko6_hiERTRldgDROOJBQCH;void(*mc_VAvAkWmhpT_WWme_3E1U91)(const void*
mc_kDRphcAfRHSbf1ZLKEDW9k,const PmIntVector*mc_VgqbsB_3R4GTjLQeEYi1Qc,
mc_Vfjzfv7SnSWthXl7BAncu7*mc__d1alWYexptL_X5HTFhbNK);const void*(*
mc_FXz9GdGvpOKnh5e2dYstBe)(const McIntFunction*mc_k0CXwzVaibdnZiGUCx6PMZ);void
(*mDestroy)(McIntFunction*mc_k0CXwzVaibdnZiGUCx6PMZ);};typedef struct
mc_kIf5GUUnTAOChauG3_6hhe mc_k3jb_ssG91tZa9bwLjlWEj;struct McMatrixFunctionTag
{mc_k3jb_ssG91tZa9bwLjlWEj*mc_ko6_hiERTRldgDROOJBQCH;const PmSparsityPattern*
mc_kjWUPQN_Ui4d_enzFJIsF_;void(*mc_VAvAkWmhpT_WWme_3E1U91)(const void*
mc_kDRphcAfRHSbf1ZLKEDW9k,const PmRealVector*mc_VgqbsB_3R4GTjLQeEYi1Qc,
mc_k3jb_ssG91tZa9bwLjlWEj*mc__d1alWYexptL_X5HTFhbNK);const void*(*
mc_FXz9GdGvpOKnh5e2dYstBe)(const McMatrixFunction*mc_k0CXwzVaibdnZiGUCx6PMZ);
void(*mDestroy)(McMatrixFunction*mc_k0CXwzVaibdnZiGUCx6PMZ);};struct
ssc_sli__kS2YfwGyKC6bHrot_r1HQ{ssc_sli_VMjb5gEwDk_XYTR_Pn6Gw3*
ssc_sli_V5OjDlpW5_degH5iUswAWm;NeDynamicSystemInput*
ssc_sli_VDf6XyVKSXWLWqE3B7oqAB;unsigned int ssc_sli__olaQHQVmVKxem053d04Yq;
unsigned int ssc_sli_FVGLRAKqpkKOWaPqeUogzr;NeuDiagnosticManager*
ssc_sli_Fa3Lvn8rpvp0XTMg9lLAt7;};static void ssc_sli__TSE8VIBEoOSdurS4nM9Zn(
ssc_sli_VVLRXiA4WGpZVaIFYAN8PM*manager){if(manager!=NULL){PmAllocator*a=
pm_default_allocator();pm_VeffaD_A8DxagH31Usec1H(&(manager->
ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->ssc_sli_V5OjDlpW5_degH5iUswAWm->
ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn.ssc_sli__X0aAlJnshW5a5o4_p4iqY),a);
pm_VeffaD_A8DxagH31Usec1H(&(manager->ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->
ssc_sli_V5OjDlpW5_degH5iUswAWm->ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn.
ssc_sli_kMWILSrh3_4vaLiThqAZTo),a);pm_FvcKvutPfxG9Xe1kjs7gg0(&(manager->
ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->ssc_sli_V5OjDlpW5_degH5iUswAWm->
ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn.ssc_sli_Vx2DkH_aGwC6aD1vs_p7b5),a);
pm_FvcKvutPfxG9Xe1kjs7gg0(&(manager->ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->
ssc_sli_V5OjDlpW5_degH5iUswAWm->ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn.
ssc_sli_Vd_K4At54IxecuOLwYFqBS),a);pm_VeffaD_A8DxagH31Usec1H(&(manager->
ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->ssc_sli_V5OjDlpW5_degH5iUswAWm->
ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn.ssc_sli_FxAWURAOat0g_9RImPYOww),a);
neu_destroy_dynamic_system_input(manager->ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->
ssc_sli_VDf6XyVKSXWLWqE3B7oqAB,a);if(manager->ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->
ssc_sli_Fa3Lvn8rpvp0XTMg9lLAt7!=NULL){(manager->ssc_sli__nuQtF0ZiztwhuJ2yPfZyu
->ssc_sli_Fa3Lvn8rpvp0XTMg9lLAt7)->mDestroy(manager->
ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->ssc_sli_Fa3Lvn8rpvp0XTMg9lLAt7);}{void*
ssc_sli_kk06poLCQlh5i5Yv6GSh7e=(manager->ssc_sli__nuQtF0ZiztwhuJ2yPfZyu);if(
ssc_sli_kk06poLCQlh5i5Yv6GSh7e!=0){(a)->mFreeFcn(a,
ssc_sli_kk06poLCQlh5i5Yv6GSh7e);}};{void*ssc_sli_kk06poLCQlh5i5Yv6GSh7e=(
manager);if(ssc_sli_kk06poLCQlh5i5Yv6GSh7e!=0){(a)->mFreeFcn(a,
ssc_sli_kk06poLCQlh5i5Yv6GSh7e);}};}}static void ssc_sli_FEgVES4jeDG_bDpk85JdmF
(ssc_sli_VVLRXiA4WGpZVaIFYAN8PM*manager){(void)manager;}static void
ssc_sli_V9nRabcO4iK5bPQb2T8_j_(ssc_sli_VVLRXiA4WGpZVaIFYAN8PM*manager,real_T
const time,real_T const*ssc_sli__EvZPycF9p4_YTSoYvLvQN,double*buffer){if(
buffer!=NULL&&manager->ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->
ssc_sli_FVGLRAKqpkKOWaPqeUogzr>0){size_t ssc_sli__FzHy7eP4U8mYieLA8vxNL=
manager->ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->ssc_sli_VDf6XyVKSXWLWqE3B7oqAB->mU.mN
;size_t ssc_core_kWAFYs9e5LChXqH2wQXohB=manager->
ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->ssc_sli_VDf6XyVKSXWLWqE3B7oqAB->mX.mN;
PmRealVector ssc_sli__S5N3OLbW_4HcaxM9_qWn_;size_t
ssc_sli_VPoUbJUlYg0WaXdmtt1Huf=0;size_t ssc_sli_kh3C5f6ZAPlGWXfJykpWPn;manager
->ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->ssc_sli_VDf6XyVKSXWLWqE3B7oqAB->mT.mX[0]=
time;for(ssc_sli_kh3C5f6ZAPlGWXfJykpWPn=0;ssc_sli_kh3C5f6ZAPlGWXfJykpWPn<
ssc_sli__FzHy7eP4U8mYieLA8vxNL;++ssc_sli_kh3C5f6ZAPlGWXfJykpWPn){manager->
ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->ssc_sli_VDf6XyVKSXWLWqE3B7oqAB->mU.mX[
ssc_sli_kh3C5f6ZAPlGWXfJykpWPn]=ssc_sli__EvZPycF9p4_YTSoYvLvQN[
ssc_sli_VPoUbJUlYg0WaXdmtt1Huf];ssc_sli_VPoUbJUlYg0WaXdmtt1Huf+=manager->
ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->ssc_sli__olaQHQVmVKxem053d04Yq;}if(
ssc_core_kWAFYs9e5LChXqH2wQXohB>0){memcpy(manager->
ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->ssc_sli_VDf6XyVKSXWLWqE3B7oqAB->mX.mX,&
ssc_sli__EvZPycF9p4_YTSoYvLvQN[ssc_sli_VPoUbJUlYg0WaXdmtt1Huf],
ssc_core_kWAFYs9e5LChXqH2wQXohB*sizeof(real_T));}
ssc_sli__S5N3OLbW_4HcaxM9_qWn_.mN=manager->ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->
ssc_sli_FVGLRAKqpkKOWaPqeUogzr;ssc_sli__S5N3OLbW_4HcaxM9_qWn_.mX=buffer;
ssc_sli_VUJoYf7OYcxCe1PJqvn5lf(manager->ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->
ssc_sli_V5OjDlpW5_degH5iUswAWm,manager->ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->
ssc_sli_VDf6XyVKSXWLWqE3B7oqAB,&ssc_sli__S5N3OLbW_4HcaxM9_qWn_,manager->
ssc_sli__nuQtF0ZiztwhuJ2yPfZyu->ssc_sli_Fa3Lvn8rpvp0XTMg9lLAt7);}}static void
ssc_sli__bvzwLkHn6xOV1tVnElcBh(PmRealVector*mc_V2mBNcV1EqCifyH9UdCbkF,const
PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,PmAllocator*a){
pm_create_real_vector_fields(mc_V2mBNcV1EqCifyH9UdCbkF,
mc__XfQXtB6cfd9fyc_v3eEup->mN,a);pm_rv_equals_rv(mc_V2mBNcV1EqCifyH9UdCbkF,
mc__XfQXtB6cfd9fyc_v3eEup);}static void ssc_sli_V1pnLAVnkZhYXHtaEn5Si5(
PmSparsityPattern*mc_V2mBNcV1EqCifyH9UdCbkF,const PmSparsityPattern*
mc__XfQXtB6cfd9fyc_v3eEup,PmAllocator*a){pm_kkW9oQAVI7Wt_9Rzuat5bx(
mc_V2mBNcV1EqCifyH9UdCbkF,((size_t)(mc__XfQXtB6cfd9fyc_v3eEup)->mJc[(
mc__XfQXtB6cfd9fyc_v3eEup)->mNumCol]),mc__XfQXtB6cfd9fyc_v3eEup->mNumRow,
mc__XfQXtB6cfd9fyc_v3eEup->mNumCol,a);pm_kTFq3qlgTulWiT6pafkmmT(
mc_V2mBNcV1EqCifyH9UdCbkF,mc__XfQXtB6cfd9fyc_v3eEup);}static void
ssc_sli_FiisGClOue8bau79ymCcRI(ssc_sli_VMjb5gEwDk_XYTR_Pn6Gw3*
mc_V2mBNcV1EqCifyH9UdCbkF,const ssc_sli_VMjb5gEwDk_XYTR_Pn6Gw3*
mc__XfQXtB6cfd9fyc_v3eEup,PmAllocator*a){ssc_sli__bvzwLkHn6xOV1tVnElcBh(&(
mc_V2mBNcV1EqCifyH9UdCbkF->ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn.
ssc_sli__X0aAlJnshW5a5o4_p4iqY),&(mc__XfQXtB6cfd9fyc_v3eEup->
ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn.ssc_sli__X0aAlJnshW5a5o4_p4iqY),a);
ssc_sli__bvzwLkHn6xOV1tVnElcBh(&(mc_V2mBNcV1EqCifyH9UdCbkF->
ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn.ssc_sli_kMWILSrh3_4vaLiThqAZTo),&(
mc__XfQXtB6cfd9fyc_v3eEup->ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn.
ssc_sli_kMWILSrh3_4vaLiThqAZTo),a);ssc_sli_V1pnLAVnkZhYXHtaEn5Si5(&(
mc_V2mBNcV1EqCifyH9UdCbkF->ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn.
ssc_sli_Vx2DkH_aGwC6aD1vs_p7b5),&(mc__XfQXtB6cfd9fyc_v3eEup->
ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn.ssc_sli_Vx2DkH_aGwC6aD1vs_p7b5),a);
ssc_sli_V1pnLAVnkZhYXHtaEn5Si5(&(mc_V2mBNcV1EqCifyH9UdCbkF->
ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn.ssc_sli_Vd_K4At54IxecuOLwYFqBS),&(
mc__XfQXtB6cfd9fyc_v3eEup->ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn.
ssc_sli_Vd_K4At54IxecuOLwYFqBS),a);ssc_sli__bvzwLkHn6xOV1tVnElcBh(&(
mc_V2mBNcV1EqCifyH9UdCbkF->ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn.
ssc_sli_FxAWURAOat0g_9RImPYOww),&(mc__XfQXtB6cfd9fyc_v3eEup->
ssc_sli_F5Ot_CwZa2dAjaZKH4fZtn.ssc_sli_FxAWURAOat0g_9RImPYOww),a);}
ssc_sli_VVLRXiA4WGpZVaIFYAN8PM*ssc_lti_create_rtw_log_fcn_manager(const
ssc_sli_VMjb5gEwDk_XYTR_Pn6Gw3*ssc_sli_FYzfxIMyuJ0Miil_d9sZRR,real_T
ssc_core_VLqJ3svt4etifXi9ymcxVh,unsigned int ssc_sli__FzHy7eP4U8mYieLA8vxNL,
unsigned int ssc_core_kWAFYs9e5LChXqH2wQXohB,unsigned int
ssc_sli_FvABE_TRVHxHfyWgjkDczK,unsigned int ssc_sli_VCo8SY6nzo_VgHvcPodhHy,
NeuDiagnosticManager*ssc_sli_VSMZoNPtzlGdfyr7dHkXMr){PmAllocator*a=
pm_default_allocator();ssc_sli_VVLRXiA4WGpZVaIFYAN8PM*
ssc_sli_VSwb7ztyca8agyN3JUVYfK=((a)->mCallocFcn((a),(1),(sizeof(
ssc_sli_VVLRXiA4WGpZVaIFYAN8PM))));ssc_sli_VryjWf9wHphDeeRWoDuv4k*
ssc_sli__ej8XyCPJitBiuYDoqd9KP=((a)->mCallocFcn((a),(1),(sizeof(
ssc_sli_VryjWf9wHphDeeRWoDuv4k))));NeDynamicSystemInputSizes sizes;size_t
ssc_sli_kh3C5f6ZAPlGWXfJykpWPn;ssc_sli__ej8XyCPJitBiuYDoqd9KP->
ssc_sli_V5OjDlpW5_degH5iUswAWm=((a)->mCallocFcn((a),(1),(sizeof(
ssc_sli_VMjb5gEwDk_XYTR_Pn6Gw3))));ssc_sli_FiisGClOue8bau79ymCcRI(
ssc_sli__ej8XyCPJitBiuYDoqd9KP->ssc_sli_V5OjDlpW5_degH5iUswAWm,
ssc_sli_FYzfxIMyuJ0Miil_d9sZRR,a);for(ssc_sli_kh3C5f6ZAPlGWXfJykpWPn=0;
ssc_sli_kh3C5f6ZAPlGWXfJykpWPn<NE_NUM_DYNAMIC_SYSTEM_INPUT_ID;++
ssc_sli_kh3C5f6ZAPlGWXfJykpWPn){sizes.mSizes[ssc_sli_kh3C5f6ZAPlGWXfJykpWPn]=0
;}sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_U]=ssc_sli__FzHy7eP4U8mYieLA8vxNL;
sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_X]=ssc_core_kWAFYs9e5LChXqH2wQXohB;
sizes.mSizes[NE_DYNAMIC_SYSTEM_INPUT_ID_T]=1;sizes.mSizes[
NE_DYNAMIC_SYSTEM_INPUT_ID_S]=1;ssc_sli__ej8XyCPJitBiuYDoqd9KP->
ssc_sli_VDf6XyVKSXWLWqE3B7oqAB=neu_create_dynamic_system_input(sizes,a);
ssc_sli__ej8XyCPJitBiuYDoqd9KP->ssc_sli_VDf6XyVKSXWLWqE3B7oqAB->mS.mX[0]=
ssc_core_VLqJ3svt4etifXi9ymcxVh;ssc_sli__ej8XyCPJitBiuYDoqd9KP->
ssc_sli__olaQHQVmVKxem053d04Yq=ssc_sli_FvABE_TRVHxHfyWgjkDczK;
ssc_sli__ej8XyCPJitBiuYDoqd9KP->ssc_sli_FVGLRAKqpkKOWaPqeUogzr=
ssc_sli_VCo8SY6nzo_VgHvcPodhHy;ssc_sli__ej8XyCPJitBiuYDoqd9KP->
ssc_sli_Fa3Lvn8rpvp0XTMg9lLAt7=ssc_sli_VSMZoNPtzlGdfyr7dHkXMr;
ssc_sli_VSwb7ztyca8agyN3JUVYfK->ssc_sli__nuQtF0ZiztwhuJ2yPfZyu=
ssc_sli__ej8XyCPJitBiuYDoqd9KP;ssc_sli_VSwb7ztyca8agyN3JUVYfK->
ssc_sli_VF5T7_4o_U8sh9eS4_Ee3s=ssc_sli_FEgVES4jeDG_bDpk85JdmF;
ssc_sli_VSwb7ztyca8agyN3JUVYfK->ssc_sli_FkOnu54reaGRbeQmmTIPpX=
ssc_sli_V9nRabcO4iK5bPQb2T8_j_;ssc_sli_VSwb7ztyca8agyN3JUVYfK->
ssc_sli_Vi_8vOV9RH_Of91AvTG8Aa=ssc_sli__TSE8VIBEoOSdurS4nM9Zn;return
ssc_sli_VSwb7ztyca8agyN3JUVYfK;}
