#ifndef __ssc_dae_fwd_h__
#define __ssc_dae_fwd_h__
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
typedef struct NeCustomDataSizeTag NeCustomDataSize;typedef struct
NeCustomDataTag NeCustomData;typedef struct NeDaeTag NeDae;typedef struct
NeRealFunctorDataTag NeRealFunctorData;typedef struct NeRealFunctorTag
NeRealFunctor;typedef struct StateTracerTag StateTracer;
#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __ssc_dae_fwd_h__ */
