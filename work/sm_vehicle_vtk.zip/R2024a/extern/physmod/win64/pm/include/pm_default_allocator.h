#ifndef __pm_default_allocator_h__
#define __pm_default_allocator_h__
#include "pm_std.h"
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
PmAllocator*pm_default_allocator(void);
#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __pm_default_allocator_h__ */
