#ifndef __pm_math_canonicalAngle_h__
#define __pm_math_canonicalAngle_h__
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
double pm_math_canonicalAngle(double theta);double pm_math_synchronizeAngle(
double approxNonModAngle,double exactModularAngle);
#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __pm_math_canonicalAngle_h__ */
