#ifndef __pm_math_gaussian_elimination_h__
#define __pm_math_gaussian_elimination_h__
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
void pm_math_lin_alg_geSolve2x2(const real_T A[4],const real_T b[2],real_T x[2
]);
#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __pm_math_gaussian_elimination_h__ */
