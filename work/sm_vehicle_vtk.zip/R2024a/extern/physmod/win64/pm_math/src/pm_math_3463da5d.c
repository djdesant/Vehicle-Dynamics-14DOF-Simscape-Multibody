#include "pm_std.h"
#include "stddef.h"
#include "pm_std.h"
extern real_T pm_math_VnOEjVNyg2OZhucGc5E7EV;extern real_T
pm_math_VS_DaUL57WSYYqKdhOZhAh;extern real_T pm_math_FlzEJVEXHExB_HzmP_4DCn;
extern real32_T pm_math_FbzPcgniy7ldiP9jki1kva;extern real32_T
pm_math_VXzHwLau5r0Jh1hUy2Bmz9;extern real32_T pm_math__GrRRdc1Zn8FXHIp4WdZwI;
extern void pm_math__q6vs_E9mICEhq7U4Gz9lI(size_t
pm_math_FpJeiUKpmBKFaHvp42RGuS);extern boolean_T pm_math_FKbWI5oUVjCZZe_cTAJ6Ic
(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern boolean_T
pm_math_VdM_6HcFx_xL_5LdjcZ7os(real32_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern
boolean_T pm_math_ky6GmdNS7wdyiTXxHKu5b_(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx
);extern boolean_T pm_math_VJGDZZVQuR8__LXaPq08E0(real32_T
pm_math_kg4CyRgbu6OdeewZOel7Qx);typedef struct{struct{uint32_T
pm_math__ARTIDuiem4sfDDt8LmBon;uint32_T pm_math_FhD1Saz7ZedmceSGBn3Lu9;}
pm_math_FRl2WNCcA_CVZ1mCqjGWQg;}pm_math_k9JbamRSA8KJfTkbhKNlzj;typedef struct{
struct{uint32_T pm_math_FhD1Saz7ZedmceSGBn3Lu9;uint32_T
pm_math__ARTIDuiem4sfDDt8LmBon;}pm_math_FRl2WNCcA_CVZ1mCqjGWQg;}
pm_math_VOGaPgsZpCx_Vy8G1ynQHA;typedef struct{union{real32_T
pm_math_VpUvuayfPZCoZaqi9TlQTF;uint32_T pm_math_FaKzb6mka3hHWHjqYy3m5v;}
pm_math_FhD1Saz7ZedmceSGBn3Lu9;}pm_math__87B1TG2jL0Sf5EO4yoSqA;extern real_T
pm_math_k3LFQ9dUQWKLYaAJxfDxcs(void);extern real32_T
pm_math_FdWy1cDiVFhKbisV_wNFSi(void);extern real_T
pm_math_FYMsJbFdY5WzfPyn5ZNxqQ(void);extern real32_T
pm_math_kPSjT86kWOhf_qVoJ77weI(void);extern real_T
pm_math__VDYpsDD5dCWXe6RxmBx5q(void);extern real32_T
pm_math__liPdaQW8oW2iPJAYQyuiW(void);real_T pm_math_VnOEjVNyg2OZhucGc5E7EV;
real_T pm_math_VS_DaUL57WSYYqKdhOZhAh;real_T pm_math_FlzEJVEXHExB_HzmP_4DCn;
real32_T pm_math_FbzPcgniy7ldiP9jki1kva;real32_T pm_math_VXzHwLau5r0Jh1hUy2Bmz9
;real32_T pm_math__GrRRdc1Zn8FXHIp4WdZwI;void pm_math__q6vs_E9mICEhq7U4Gz9lI(
size_t pm_math_FpJeiUKpmBKFaHvp42RGuS){(void)(pm_math_FpJeiUKpmBKFaHvp42RGuS);
pm_math_FlzEJVEXHExB_HzmP_4DCn=pm_math_k3LFQ9dUQWKLYaAJxfDxcs();
pm_math__GrRRdc1Zn8FXHIp4WdZwI=pm_math_FdWy1cDiVFhKbisV_wNFSi();
pm_math_VnOEjVNyg2OZhucGc5E7EV=pm_math_FYMsJbFdY5WzfPyn5ZNxqQ();
pm_math_FbzPcgniy7ldiP9jki1kva=pm_math_kPSjT86kWOhf_qVoJ77weI();
pm_math_VS_DaUL57WSYYqKdhOZhAh=pm_math__VDYpsDD5dCWXe6RxmBx5q();
pm_math_VXzHwLau5r0Jh1hUy2Bmz9=pm_math__liPdaQW8oW2iPJAYQyuiW();}boolean_T
pm_math_FKbWI5oUVjCZZe_cTAJ6Ic(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx){return((
pm_math_kg4CyRgbu6OdeewZOel7Qx==pm_math_VnOEjVNyg2OZhucGc5E7EV||
pm_math_kg4CyRgbu6OdeewZOel7Qx==pm_math_VS_DaUL57WSYYqKdhOZhAh)?1U:0U);}
boolean_T pm_math_VdM_6HcFx_xL_5LdjcZ7os(real32_T
pm_math_kg4CyRgbu6OdeewZOel7Qx){return(((pm_math_kg4CyRgbu6OdeewZOel7Qx)==
pm_math_FbzPcgniy7ldiP9jki1kva||(pm_math_kg4CyRgbu6OdeewZOel7Qx)==
pm_math_VXzHwLau5r0Jh1hUy2Bmz9)?1U:0U);}boolean_T
pm_math_ky6GmdNS7wdyiTXxHKu5b_(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx){return(
pm_math_kg4CyRgbu6OdeewZOel7Qx!=pm_math_kg4CyRgbu6OdeewZOel7Qx)?1U:0U;}
boolean_T pm_math_VJGDZZVQuR8__LXaPq08E0(real32_T
pm_math_kg4CyRgbu6OdeewZOel7Qx){return(pm_math_kg4CyRgbu6OdeewZOel7Qx!=
pm_math_kg4CyRgbu6OdeewZOel7Qx)?1U:0U;}
