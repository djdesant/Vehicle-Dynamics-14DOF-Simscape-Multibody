#include "pm_std.h"
#include "pm_std.h"
void pm_math_VWv_QvuNRm4viyJPPMYOkS(const real_T*
pm_math__ut5UfJwzNlZ_XZC_yEgKo,const real_T*b,uint32_T n,boolean_T
pm_math_FEqGkTLIgMdKjaJ1lIV70b,real_T*x);void pm_math_VRlre4EWbUOCcXxk9GINjY(
const real_T*pm_math_Vi4Cp0qK964NYTFMGr9Ttn,const real_T*b,uint32_T n,
boolean_T pm_math_FEqGkTLIgMdKjaJ1lIV70b,real_T*x);void
pm_math_VWv_QvuNRm4viyJPPMYOkS(const real_T*pm_math__ut5UfJwzNlZ_XZC_yEgKo,
const real_T*b,uint32_T n,boolean_T pm_math_FEqGkTLIgMdKjaJ1lIV70b,real_T*x){
uint32_T pm_math_kwrB3ZoKf7OufTHWaHJV7a,pm_math_kyp6uAyJE40UVuAQNEYzS1;for(
pm_math_kwrB3ZoKf7OufTHWaHJV7a=0;pm_math_kwrB3ZoKf7OufTHWaHJV7a<n;x-=
pm_math_kwrB3ZoKf7OufTHWaHJV7a,pm_math_kwrB3ZoKf7OufTHWaHJV7a++){real_T
pm_math_FQferGZUKft3_i5GvYy4Oy=0.0;const real_T*pm_math_FL1llpmubk_sXeD10Sbe3f
=pm_math__ut5UfJwzNlZ_XZC_yEgKo++;for(pm_math_kyp6uAyJE40UVuAQNEYzS1=0;
pm_math_kyp6uAyJE40UVuAQNEYzS1<pm_math_kwrB3ZoKf7OufTHWaHJV7a;++
pm_math_kyp6uAyJE40UVuAQNEYzS1,pm_math_FL1llpmubk_sXeD10Sbe3f+=n)
pm_math_FQferGZUKft3_i5GvYy4Oy+= *pm_math_FL1llpmubk_sXeD10Sbe3f**x++;*x=
pm_math_FEqGkTLIgMdKjaJ1lIV70b?(*b++-pm_math_FQferGZUKft3_i5GvYy4Oy):((*b++-
pm_math_FQferGZUKft3_i5GvYy4Oy)/ *pm_math_FL1llpmubk_sXeD10Sbe3f);}}void
pm_math_VRlre4EWbUOCcXxk9GINjY(const real_T*pm_math_Vi4Cp0qK964NYTFMGr9Ttn,
const real_T*b,uint32_T n,boolean_T pm_math_FEqGkTLIgMdKjaJ1lIV70b,real_T*x){
uint32_T pm_math_kwrB3ZoKf7OufTHWaHJV7a,pm_math_kyp6uAyJE40UVuAQNEYzS1;
pm_math_Vi4Cp0qK964NYTFMGr9Ttn+=n*n;b+=n-1;x+=n-1;for(
pm_math_kwrB3ZoKf7OufTHWaHJV7a=0;pm_math_kwrB3ZoKf7OufTHWaHJV7a<n;x+=
pm_math_kwrB3ZoKf7OufTHWaHJV7a,pm_math_kwrB3ZoKf7OufTHWaHJV7a++){real_T
pm_math_FQferGZUKft3_i5GvYy4Oy=0.0;const real_T*pm_math_FL1llpmubk_sXeD10Sbe3f
= --pm_math_Vi4Cp0qK964NYTFMGr9Ttn;for(pm_math_kyp6uAyJE40UVuAQNEYzS1=
pm_math_kwrB3ZoKf7OufTHWaHJV7a;pm_math_kyp6uAyJE40UVuAQNEYzS1>0;
pm_math_FL1llpmubk_sXeD10Sbe3f-=n,--pm_math_kyp6uAyJE40UVuAQNEYzS1)
pm_math_FQferGZUKft3_i5GvYy4Oy+= *pm_math_FL1llpmubk_sXeD10Sbe3f**x--;*x=
pm_math_FEqGkTLIgMdKjaJ1lIV70b?(*b-- -pm_math_FQferGZUKft3_i5GvYy4Oy):((*b-- -
pm_math_FQferGZUKft3_i5GvYy4Oy)/ *pm_math_FL1llpmubk_sXeD10Sbe3f);}}
