#include "pm_std.h"
#include "pm_std.h"
extern real_T pm_math_V6hUjCc3PiCAauyMwJP5nb;extern real_T
pm_math_Vco4W7EuZu4k_1cAN9SDVG;extern real_T pm_math_k9HpTo0HuFt0gDRVyg17Wc;
extern real32_T pm_math__JOzYwXJOmSsiaZ6WMnnZZ;extern real32_T
pm_math_VaGr_igKLHx0bDW9g54I6v;extern real32_T pm_math_kZu0y5Pv4G8tg1EE_V6tGP;
extern void pm_math_F3OoZ1Weno85bujDCIyv_c(void);extern boolean_T
pm_math__LIYjt5pi54rVTuNKI6I5_(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern
boolean_T pm_math_VK2BuaMRCmOxjLjqE4tZMh(real32_T
pm_math_kg4CyRgbu6OdeewZOel7Qx);extern boolean_T pm_math__J9snrOx2Cp4dD_e3lGtRm
(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern boolean_T
pm_math_kwH13YYrpKtAbDLZ9Q_8I9(real32_T pm_math_kg4CyRgbu6OdeewZOel7Qx);
#include "stddef.h"
extern real_T pm_math_kYp7q1jaClWaV10HRELoHW(void);extern real32_T
pm_math_Vqb3e0m4zk4HbepgEB67lF(void);real_T pm_math_kYp7q1jaClWaV10HRELoHW(
void){return pm_math_k9HpTo0HuFt0gDRVyg17Wc;}real32_T
pm_math_Vqb3e0m4zk4HbepgEB67lF(void){return pm_math_kZu0y5Pv4G8tg1EE_V6tGP;}
