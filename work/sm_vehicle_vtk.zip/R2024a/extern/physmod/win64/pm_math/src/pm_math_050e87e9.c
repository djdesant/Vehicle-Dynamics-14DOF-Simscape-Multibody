#include "pm_std.h"
#include "pm_std.h"
extern real_T pm_math_V6hUjCc3PiCAauyMwJP5nb;extern real_T
pm_math_Vco4W7EuZu4k_1cAN9SDVG;extern real_T pm_math_k9HpTo0HuFt0gDRVyg17Wc;
extern real32_T pm_math__JOzYwXJOmSsiaZ6WMnnZZ;extern real32_T
pm_math_VaGr_igKLHx0bDW9g54I6v;extern real32_T pm_math_kZu0y5Pv4G8tg1EE_V6tGP;
extern void pm_math_F3OoZ1Weno85bujDCIyv_c(void);extern boolean_T
pm_math__LIYjt5pi54rVTuNKI6I5_(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern
boolean_T pm_math_VK2BuaMRCmOxjLjqE4tZMh(real32_T
pm_math_kg4CyRgbu6OdeewZOel7Qx);extern boolean_T pm_math__J9snrOx2Cp4dD_e3lGtRm
(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern boolean_T
pm_math_kwH13YYrpKtAbDLZ9Q_8I9(real32_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern
real_T pm_math__UArQ87igoKpXyfaZJjv_s(void);extern real32_T
pm_math__k5KCfm4hHplaXUS87ikZr(void);extern real_T
pm_math__8a8Lh1nurlUi1vId_nTEY(void);extern real32_T
pm_math_FvOxQ6N5WiGLaumBF4EGEL(void);real_T pm_math__UArQ87igoKpXyfaZJjv_s(
void){return pm_math_V6hUjCc3PiCAauyMwJP5nb;}real32_T
pm_math__k5KCfm4hHplaXUS87ikZr(void){return pm_math__JOzYwXJOmSsiaZ6WMnnZZ;}
real_T pm_math__8a8Lh1nurlUi1vId_nTEY(void){return
pm_math_Vco4W7EuZu4k_1cAN9SDVG;}real32_T pm_math_FvOxQ6N5WiGLaumBF4EGEL(void){
return pm_math_VaGr_igKLHx0bDW9g54I6v;}
