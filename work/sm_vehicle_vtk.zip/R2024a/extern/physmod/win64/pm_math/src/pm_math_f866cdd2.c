#include "stddef.h"
#include "stdlib.h"
#include "pm_std.h"
extern void pm_math__wo8gjKHkd4ZYiGnRCCA8L(creal_T*x);
#include "pm_std.h"
extern void pm_math_V4wY5inRPrGJ_q94UMd56c(const int
pm_math_FdNKyaRLqeWhg5tGqF_VYT,const int pm_math__jwySfHyx1SXgXJeVWoIzb,const
real_T*pm_math_F2l4p_g4sn02huHNflQjMH,const real_T*
pm_math_Vqiy96WqvuhCaXm5e_vvT0,creal_T*pm_math_kJeUz19e49pVaDwcttsZep,creal_T*
pm_math_kyfq6L_eQbdYcPuOovpRDW,creal_T*pm_math_kXii4Miq3Y_ShPn9EHS3D5,creal_T*
pm_math_FYAUa2zJy8Cah1YsdPJok5,creal_T*pm_math__Vu43oWQSkpLiuph6ye1KN,creal_T*
pm_math_VHUYV1kdST0efLHvpiBBXm,creal_T*pm_math_VRZCD_UL_ESThy75dC9J8D,creal_T*
pm_math_Fo1tUR18sIdue1E1QXuOnL,creal_T*pm_math___7SXc4Q_w8saDIIf2ecjp,real_T*
pm_math_ktFLct2wbuxD_5iTvRiZEZ,real_T*pm_math_kHM1aMQ_rJdeheUxTze_oV,int32_T*
pm_math__qLHk6daYiGnXenMNt2kR_,int8_T*pm_math_VS3xMd4pLil0i5cxPD0ErK);
#include "pm_std.h"
extern double pm_math_kwMWlgVR1IlmY1byW81iKg(double
pm_math_kX_3wpayBuGfayGjLiZlmB,double pm_math_FkicuWr3zNG_VHwcasJgXR);
#include "pm_std.h"
extern real_T pm_math_V6hUjCc3PiCAauyMwJP5nb;extern real_T
pm_math_Vco4W7EuZu4k_1cAN9SDVG;extern real_T pm_math_k9HpTo0HuFt0gDRVyg17Wc;
extern real32_T pm_math__JOzYwXJOmSsiaZ6WMnnZZ;extern real32_T
pm_math_VaGr_igKLHx0bDW9g54I6v;extern real32_T pm_math_kZu0y5Pv4G8tg1EE_V6tGP;
extern void pm_math_F3OoZ1Weno85bujDCIyv_c(void);extern boolean_T
pm_math__LIYjt5pi54rVTuNKI6I5_(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern
boolean_T pm_math_VK2BuaMRCmOxjLjqE4tZMh(real32_T
pm_math_kg4CyRgbu6OdeewZOel7Qx);extern boolean_T pm_math__J9snrOx2Cp4dD_e3lGtRm
(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern boolean_T
pm_math_kwH13YYrpKtAbDLZ9Q_8I9(real32_T pm_math_kg4CyRgbu6OdeewZOel7Qx);
#include "pm_std.h"
extern void pm_math__rpEXF0kArpajmJg_Jv0eW(const creal_T
pm_math_Fe6copTTRcKEayCm87ABO_,const creal_T pm_math_VoTkdAz8Qxd2iDKiMSyIbK,
double*pm_math_F5Olyc6xUoG7ZyDq78exBD,creal_T*pm_math_kgWQ_oIWTKdXZyfD4IYR1F);
extern void pm_math__wt7gD7RMvKZaeZRgAma6O(const creal_T
pm_math_Fe6copTTRcKEayCm87ABO_,const creal_T pm_math_VoTkdAz8Qxd2iDKiMSyIbK,
double*pm_math_F5Olyc6xUoG7ZyDq78exBD,creal_T*pm_math_kgWQ_oIWTKdXZyfD4IYR1F,
creal_T*pm_math_kUQBO1dSP8_IVqRAUx4R8G);
#include "math.h"
#include "pm_std.h"
void pm_math__wo8gjKHkd4ZYiGnRCCA8L(creal_T*x){double
pm_math_VUH4EpnPQkWMeLg4GI_yGi;double pm_math__01SK3u3lG0GaLCTTSoVGO;double
pm_math_k3kQ9Kgz22thb9gjxPTyG4;double pm_math_k8ttlyP94dCJjXLSM2cj9q;
pm_math_VUH4EpnPQkWMeLg4GI_yGi=x->re;pm_math__01SK3u3lG0GaLCTTSoVGO=x->im;if(
pm_math__01SK3u3lG0GaLCTTSoVGO==0.0){if(pm_math_VUH4EpnPQkWMeLg4GI_yGi<0.0){
pm_math_k3kQ9Kgz22thb9gjxPTyG4=0.0;pm_math_VUH4EpnPQkWMeLg4GI_yGi=sqrt(-
pm_math_VUH4EpnPQkWMeLg4GI_yGi);}else{pm_math_k3kQ9Kgz22thb9gjxPTyG4=sqrt(
pm_math_VUH4EpnPQkWMeLg4GI_yGi);pm_math_VUH4EpnPQkWMeLg4GI_yGi=0.0;}}else if(
pm_math_VUH4EpnPQkWMeLg4GI_yGi==0.0){if(pm_math__01SK3u3lG0GaLCTTSoVGO<0.0){
pm_math_k3kQ9Kgz22thb9gjxPTyG4=sqrt(-pm_math__01SK3u3lG0GaLCTTSoVGO/2.0);
pm_math_VUH4EpnPQkWMeLg4GI_yGi= -pm_math_k3kQ9Kgz22thb9gjxPTyG4;}else{
pm_math_k3kQ9Kgz22thb9gjxPTyG4=sqrt(pm_math__01SK3u3lG0GaLCTTSoVGO/2.0);
pm_math_VUH4EpnPQkWMeLg4GI_yGi=pm_math_k3kQ9Kgz22thb9gjxPTyG4;}}else if(
pm_math__J9snrOx2Cp4dD_e3lGtRm(pm_math_VUH4EpnPQkWMeLg4GI_yGi)){
pm_math_k3kQ9Kgz22thb9gjxPTyG4=pm_math_VUH4EpnPQkWMeLg4GI_yGi;}else if(
pm_math__J9snrOx2Cp4dD_e3lGtRm(pm_math__01SK3u3lG0GaLCTTSoVGO)){
pm_math_k3kQ9Kgz22thb9gjxPTyG4=pm_math__01SK3u3lG0GaLCTTSoVGO;
pm_math_VUH4EpnPQkWMeLg4GI_yGi=pm_math__01SK3u3lG0GaLCTTSoVGO;}else if(
pm_math__LIYjt5pi54rVTuNKI6I5_(pm_math__01SK3u3lG0GaLCTTSoVGO)){
pm_math_k3kQ9Kgz22thb9gjxPTyG4=fabs(pm_math__01SK3u3lG0GaLCTTSoVGO);
pm_math_VUH4EpnPQkWMeLg4GI_yGi=pm_math__01SK3u3lG0GaLCTTSoVGO;}else if(
pm_math__LIYjt5pi54rVTuNKI6I5_(pm_math_VUH4EpnPQkWMeLg4GI_yGi)){if(
pm_math_VUH4EpnPQkWMeLg4GI_yGi<0.0){pm_math_k3kQ9Kgz22thb9gjxPTyG4=0.0;
pm_math_VUH4EpnPQkWMeLg4GI_yGi=pm_math__01SK3u3lG0GaLCTTSoVGO*-
pm_math_VUH4EpnPQkWMeLg4GI_yGi;}else{pm_math_k3kQ9Kgz22thb9gjxPTyG4=
pm_math_VUH4EpnPQkWMeLg4GI_yGi;pm_math_VUH4EpnPQkWMeLg4GI_yGi=0.0;}}else{
pm_math_k8ttlyP94dCJjXLSM2cj9q=fabs(pm_math_VUH4EpnPQkWMeLg4GI_yGi);
pm_math_k3kQ9Kgz22thb9gjxPTyG4=fabs(pm_math__01SK3u3lG0GaLCTTSoVGO);if((
pm_math_k8ttlyP94dCJjXLSM2cj9q>4.4942328371557893E+307)||(
pm_math_k3kQ9Kgz22thb9gjxPTyG4>4.4942328371557893E+307)){
pm_math_k8ttlyP94dCJjXLSM2cj9q*=0.5;pm_math_k3kQ9Kgz22thb9gjxPTyG4=
pm_math_kwMWlgVR1IlmY1byW81iKg(pm_math_k8ttlyP94dCJjXLSM2cj9q,
pm_math_k3kQ9Kgz22thb9gjxPTyG4*0.5);if(pm_math_k3kQ9Kgz22thb9gjxPTyG4>
pm_math_k8ttlyP94dCJjXLSM2cj9q){pm_math_k3kQ9Kgz22thb9gjxPTyG4=sqrt(
pm_math_k3kQ9Kgz22thb9gjxPTyG4)*sqrt(pm_math_k8ttlyP94dCJjXLSM2cj9q/
pm_math_k3kQ9Kgz22thb9gjxPTyG4+1.0);}else{pm_math_k3kQ9Kgz22thb9gjxPTyG4=sqrt(
pm_math_k3kQ9Kgz22thb9gjxPTyG4)*1.4142135623730951;}}else{
pm_math_k3kQ9Kgz22thb9gjxPTyG4=sqrt((pm_math_kwMWlgVR1IlmY1byW81iKg(
pm_math_k8ttlyP94dCJjXLSM2cj9q,pm_math_k3kQ9Kgz22thb9gjxPTyG4)+
pm_math_k8ttlyP94dCJjXLSM2cj9q)*0.5);}if(pm_math_VUH4EpnPQkWMeLg4GI_yGi>0.0){
pm_math_VUH4EpnPQkWMeLg4GI_yGi=0.5*(pm_math__01SK3u3lG0GaLCTTSoVGO/
pm_math_k3kQ9Kgz22thb9gjxPTyG4);}else{if(pm_math__01SK3u3lG0GaLCTTSoVGO<0.0){
pm_math_VUH4EpnPQkWMeLg4GI_yGi= -pm_math_k3kQ9Kgz22thb9gjxPTyG4;}else{
pm_math_VUH4EpnPQkWMeLg4GI_yGi=pm_math_k3kQ9Kgz22thb9gjxPTyG4;}
pm_math_k3kQ9Kgz22thb9gjxPTyG4=0.5*(pm_math__01SK3u3lG0GaLCTTSoVGO/
pm_math_VUH4EpnPQkWMeLg4GI_yGi);}}x->re=pm_math_k3kQ9Kgz22thb9gjxPTyG4;x->im=
pm_math_VUH4EpnPQkWMeLg4GI_yGi;}
