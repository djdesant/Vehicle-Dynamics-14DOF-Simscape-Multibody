/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'sm_vehicle_vtk/Vehicle/World/Solver Configuration'.
 */

const sm_core_compiler_Plane *sm_vehicle_vtk_836bb176_1_geometry_0(const
  RuntimeDerivedValuesBundle *rtdv);
struct RuntimeDerivedValuesBundleTag;
void sm_vehicle_vtk_836bb176_1_initializeGeometries(const struct
  RuntimeDerivedValuesBundleTag *rtdv);
