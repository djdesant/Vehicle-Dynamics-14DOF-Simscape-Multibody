/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'sm_vehicle_vtk/Vehicle/World/Solver Configuration'.
 */

#ifndef __sm_vehicle_vtk_836bb176_1_gateway_h__
#define __sm_vehicle_vtk_836bb176_1_gateway_h__
#ifdef __cplusplus

extern "C"
{

#endif

  extern void sm_vehicle_vtk_836bb176_1_gateway(void);

#ifdef __cplusplus

}

#endif
#endif                     /* #ifndef __sm_vehicle_vtk_836bb176_1_gateway_h__ */
